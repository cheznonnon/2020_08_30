// Nonnon Paint
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




static RECT n_paint_grabber_rect;
static s32  n_paint_grabber_fx;
static s32  n_paint_grabber_fy;




// internal
void
n_paint_grabber_system_get( s32 *x, s32 *y, s32 *sx, s32 *sy, s32 *fx, s32 *fy )
{

	// [!] : Why is this messy?
	//
	//	a : for reserving namespace
	//	b : for avoiding silent reference to global variables

	if ( x  != NULL ) { *x  = n_paint_grabber_rect.left;   }
	if ( y  != NULL ) { *y  = n_paint_grabber_rect.top;    }
	if ( sx != NULL ) { *sx = n_paint_grabber_rect.right;  }
	if ( sy != NULL ) { *sy = n_paint_grabber_rect.bottom; }
	if ( fx != NULL ) { *fx = n_paint_grabber_fx;          }
	if ( fy != NULL ) { *fy = n_paint_grabber_fy;          }


	return;
}

// internal
void
n_paint_grabber_system_set( s32 *x, s32 *y, s32 *sx, s32 *sy, s32 *fx, s32 *fy )
{

	if ( x  != NULL ) { n_paint_grabber_rect.left   = *x;  }
	if ( y  != NULL ) { n_paint_grabber_rect.top    = *y;  }
	if ( sx != NULL ) { n_paint_grabber_rect.right  = *sx; }
	if ( sy != NULL ) { n_paint_grabber_rect.bottom = *sy; }
	if ( fx != NULL ) { n_paint_grabber_fx          = *fx; }
	if ( fy != NULL ) { n_paint_grabber_fy          = *fy; }


	return;
}

// internal
void
n_paint_grabber_system_zero( void )
{

	s32 x,y,sx,sy,fx,fy; n_paint_grabber_system_get( &x,&y, &sx,&sy, &fx,&fy );

	x = y = sx = sy = fx = fy = 0;

	n_paint_grabber_system_set( &x,&y, &sx,&sy, &fx,&fy );


	return;
}

// internal
void
n_paint_grabber_status( void )
{

	n_posix_char str[ 100 ];


	if ( N_PAINT_GRABBER_IS_NEUTRAL()              ) { n_string_copy_literal( " Neutral",    str ); } else
	if ( N_PAINT_GRABBER_IS_SELECTING()            ) { n_string_copy_literal( " Selecting",  str ); } else
	if ( N_PAINT_GRABBER_IS_DRAG_OK()              ) { n_string_copy_literal( " Drag OK",    str ); } else
	if ( N_PAINT_GRABBER_IS_DRAGGING()             ) { n_string_copy_literal( " Dragging",   str ); } else
	if ( N_PAINT_GRABBER_IS_STRETCH_PROPORTIONAL() ) { n_string_copy_literal( " Stretching", str ); } else
	if ( N_PAINT_GRABBER_IS_STRETCH_TRANSFORM()    ) { n_string_copy_literal( " Stretching", str ); }

	n_win_statusbar_od_text( &n_paint_tool_grabber_status, str, 0 );


	s32 x,y,sx,sy,fx,fy;

	if ( N_PAINT_GRABBER_IS_NEUTRAL() )
	{
		x = y = sx = sy = fx = fy = 0;
	} else {
		n_paint_grabber_system_get( &x,&y, &sx,&sy, &fx,&fy );
	}


	n_posix_sprintf_literal( str, "\t\t%4ld %4ld ", x,y );

	n_win_statusbar_od_text( &n_paint_tool_grabber_status, str, 1 );


	n_posix_sprintf_literal( str, "\t\t%ldx%ld ", sx,sy );

	n_win_statusbar_od_text( &n_paint_tool_grabber_status, str, 2 );


	return;
}

// internal
void
n_paint_grabber_init( void )
{

	grabber = N_PAINT_GRABBER_NEUTRAL;

	n_paint_grabber_system_zero();


	return;
}

// internal
void
n_paint_grabber_resync( s32 x, s32 y, s32 sx, s32 sy )
{

//n_paint_refresh_all(); return;


	static s32 pfx = 0;
	static s32 pfy = 0;
	static s32 ptx = 0;
	static s32 pty = 0;


	pfx = n_posix_min_s32( pfx, x      );
	pfy = n_posix_min_s32( pfy, y      );
	ptx = n_posix_max_s32( ptx, x + sx );
	pty = n_posix_max_s32( pty, y + sy );

//n_bmp_box( &bmp_0, pfx,pfy, ptx-pfx,pty-pfy, n_bmp_rgb( 0,200,255 ) );

	n_paint_refresh( NULL, pfx,pfy, ptx,pty, N_PAINT_REFRESH_CLIENT );

	pfx = x;
	pfy = y;
	ptx = x + sx;
	pty = y + sy;


	return;
}

void
n_paint_grabber_resync_auto( void )
{

	s32 x,y,sx,sy; n_paint_grabber_system_get( &x,&y, &sx,&sy, NULL,NULL );

	n_paint_grabber_resync( x,y,sx,sy );


	return;
}

// internal
void
n_paint_grabber_composition( n_bmp *grab, n_bmp *target, bool finalize, bool frame )
{

	if ( N_PAINT_GRABBER_IS_NEUTRAL() ) { return; }


	s32 x,y,sx,sy; n_paint_grabber_system_get( &x,&y, &sx,&sy, NULL,NULL );

	if ( frame )
	{
		n_draw_frame( target, x-1,y-1,sx+2,sy+2, n_bmp_white, n_bmp_black );
	}

//return;
	if (
		( n_paint_tool_per_pixel_alpha_onoff )
		||
		( n_paint_tool_blend )
	)
	{
		n_bmp_blendcopy_internal( grab, target, 0,0,sx,sy, x,y, finalize, n_paint_tool_blend_ratio );
	} else {
		n_bmp_fastcopy( grab, target, 0,0,sx,sy, x,y );
	}


	return;
}

// internal
void
n_paint_grabber_reset( void )
{

	int i = 0;
	while( 1 )
	{
		n_bmp_free( &n_paint_layer_data[ i ].bmp_grab );

		i++;
		if ( i >= n_paint_layer_count ) { break; }
	}

	n_paint_grabber_init();

	n_paint_grabber_resync_auto();


	// [!] : for usability
	//n_paint_tool_grabber_trans_onoff( false );


	n_paint_tool_grabber_blend_zero();


	n_paint_layer_grabber_onoff( true );
	n_paint_layer_grabber_location( -1 );


	return;
}

// internal
void
n_paint_grabber_finish( void )
{

	if ( n_paint_grabber_wholegrb_onoff )
	{
		int i = 0;
		while( 1 )
		{
			if ( n_paint_layer_data[ i ].visible )
			{
				n_paint_grabber_composition
				(
					&n_paint_layer_data[ i ].bmp_grab,
					&n_paint_layer_data[ i ].bmp_data,
					n_paint_grabber_is_rotated,
					false
				);
			}

			i++;
			if ( i >= n_paint_layer_count ) { break; }
		}
	} else
	if ( n_paint_layer_onoff )
	{
		int i = n_paint_grabber_selected_index;

		if ( n_paint_layer_data[ i ].visible )
		{
			n_paint_grabber_composition
			(
				&n_paint_layer_data[ i ].bmp_grab,
				&n_paint_layer_data[ i ].bmp_data,
				n_paint_grabber_is_rotated,
				false
			);
		}
	} else {
		n_paint_grabber_composition( n_paint_bmp_grab, n_paint_bmp_data, true, false );
	}


	int i = 0;
	while( 1 )
	{
		n_bmp_free( &n_paint_layer_data[ i ].bmp_grab );

		i++;
		if ( i >= n_paint_layer_count ) { break; }
	}

	n_paint_grabber_init();

	n_paint_grabber_status();


	n_paint_grabber_resync_auto();


	// [!] : for usability
	//n_paint_tool_grabber_trans_onoff( false );


	n_paint_tool_grabber_blend_zero();


	n_paint_layer_grabber_onoff( true );
	n_paint_layer_grabber_location( -1 );


	n_paint_grabber_is_rotated = false;


	return;
}

// internal
void
n_paint_grabber_select( n_bmp *b, bool redraw )
{

	s32 x,y,sx,sy; n_paint_grabber_system_get( &x,&y, &sx,&sy, NULL,NULL );


	if ( n_paint_grabber_wholegrb_onoff )
	{
//n_posix_debug_literal( " 1 " );

		int i = 0;
		while( 1 )
		{//break;

			// [!] : trick : make .bmp_grab always
			//
			//	usability for visibility on/off
			//	other logic simply ignores

			//if ( n_paint_layer_data[ i ].visible )
			{
				n_bmp *bmp = &n_paint_layer_data[ i ].bmp_grab;

				if ( b == NULL )
				{

					n_bmp_new_fast( bmp, sx,sy );
					n_bmp_fastcopy( &n_paint_layer_data[ i ].bmp_data, bmp, x,y,sx,sy, 0,0 );

				} else {

					if ( n_paint_bmp_grab == bmp )
					{
						n_bmp_free( bmp );
						n_bmp_carboncopy( b, bmp );
					}
//n_bmp_flush( &n_paint_layer_data[ i ].bmp_grab, n_bmp_rgb( 255,0,200 ) );

					sx = N_BMP_SX( b );
					sy = N_BMP_SY( b );

				}
			}

			i++;
			if ( i >= n_paint_layer_count ) { break; }
		}

	} else
	if ( n_paint_layer_onoff )
	{

		if ( b == NULL )
		{
//n_posix_debug_literal( " 2-0 " );

			n_bmp_new_fast( n_paint_bmp_grab, sx,sy );
			n_bmp_fastcopy( n_paint_bmp_data, n_paint_bmp_grab, x,y,sx,sy, 0,0 );

		} else {
//n_posix_debug_literal( " 2-1 " );

			int y = n_paint_layer_txtbox.select_cch_y;

			n_paint_bmp_data = &n_paint_layer_data[ y ].bmp_data;
			n_paint_bmp_grab = &n_paint_layer_data[ y ].bmp_grab;

			n_bmp_free( n_paint_bmp_grab );
			n_bmp_carboncopy( b, n_paint_bmp_grab );

			sx = N_BMP_SX( b );
			sy = N_BMP_SY( b );

		}

	} else {
//n_posix_debug_literal( " 3 " );

		if ( b == NULL )
		{

			n_bmp_new_fast( n_paint_bmp_grab, sx,sy );
			n_bmp_fastcopy( n_paint_bmp_data, n_paint_bmp_grab, x,y,sx,sy, 0,0 );

		} else {
//n_posix_debug_literal( " %d %d ", (int) n_paint_bmp_grab, (int) &n_paint_layer_data[ 0 ].bmp_grab );

			n_bmp_free( n_paint_bmp_grab );
			n_bmp_carboncopy( b, n_paint_bmp_grab );

			sx = N_BMP_SX( b );
			sy = N_BMP_SY( b );
//n_posix_debug_literal( " %d %d ", sx, sy );
		}

	}

	n_paint_grabber_system_set( &x,&y, &sx,&sy, NULL,NULL );


	if ( redraw ) { n_paint_grabber_resync_auto(); }


	return;
}

// internal
void
n_paint_grabber_clear( void )
{

	if ( n_paint_grabber_wholegrb_onoff )
	{

		int i = 0;
		while( 1 )
		{

			if ( n_paint_layer_data[ i ].visible )
			{
				if ( n_paint_tool_per_pixel_alpha_onoff )
				{
					n_bmp_flush( &n_paint_layer_data[ i ].bmp_grab, n_bmp_white_invisible );
				} else {
					n_bmp_flush( &n_paint_layer_data[ i ].bmp_grab, n_bmp_white           );
				}
			}

			i++;
			if ( i >= n_paint_layer_count ) { break; }
		}

	} else
	if ( n_paint_layer_onoff )
	{

		if ( n_paint_tool_per_pixel_alpha_onoff )
		{
			n_bmp_flush( n_paint_bmp_grab, n_bmp_white_invisible );
		} else {
			n_bmp_flush( n_paint_bmp_grab, n_bmp_white           );
		}

	} else {

		if ( n_paint_tool_per_pixel_alpha_onoff )
		{
			n_bmp_flush( n_paint_bmp_grab, n_bmp_white_invisible );
		} else {
//n_paint_grabber_select( NULL, false );
			n_bmp_flush( n_paint_bmp_grab, n_bmp_white           );
		}

	}

	n_paint_grabber_resync_auto();


	return;
}

void
n_paint_grabber_position_reset( void )
{

	if ( N_PAINT_GRABBER_IS_NEUTRAL() ) { return; }


	s32 x,y, fx,fy; n_paint_grabber_system_get( &x,&y, NULL,NULL, &fx,&fy );

	x = fx;
	y = fy;

	n_paint_grabber_system_set( &x,&y, NULL,NULL, &fx,&fy );

	n_paint_grabber_resync_auto();


	return;
}

// internal
void
n_paint_grabber_filter_sync_calc( int filter_type )
{

	s32 psx = N_BMP_SX( n_paint_bmp_data );
	s32 psy = N_BMP_SY( n_paint_bmp_data );

	s32 x,y,sx,sy,fx,fy; n_paint_grabber_system_get( &x,&y, &sx,&sy, &fx,&fy );

	s32 px = x;
	s32 py = y;

	if ( filter_type == N_PAINT_FILTER_SCALE_LIL )
	{
		x = x / 2;
		y = y / 2;
	} else
	if ( filter_type == N_PAINT_FILTER_SCALE_BIG )
	{
		x = x * 2;
		y = y * 2;
	} else
	if ( filter_type == N_PAINT_FILTER_MIRROR    )
	{
		x = psx - ( x + sx );
	} else
	if ( filter_type == N_PAINT_FILTER_ROTATE_L  )
	{
		x = py;
		y = psx - ( px + sx );
	} else
	if ( filter_type == N_PAINT_FILTER_ROTATE_R  )
	{
		x = psy - ( py + sy );
		y = px;
	}

	fx = x;
	fy = y;

	n_paint_grabber_system_set( &x,&y, &sx,&sy, &fx,&fy );


	return;
}

// internal
bool
n_paint_grabber_filter_sync( int filter_type, bool calc, bool refresh )
{

	if ( N_PAINT_GRABBER_IS_NEUTRAL() ) { return false; }


	n_paint_filter_go( n_paint_bmp_data, filter_type );


	if ( calc ) { n_paint_grabber_filter_sync_calc( filter_type ); }


	n_bmp b; n_bmp_carboncopy( n_paint_bmp_grab, &b );

	n_paint_filter_go( &b, filter_type );

//n_paint_grabber_select( &b, false );

	{
		n_bmp_free( n_paint_bmp_grab );
		n_bmp_carboncopy( &b, n_paint_bmp_grab );

		if ( calc )
		{
			s32 sx = N_BMP_SX( &b );
			s32 sy = N_BMP_SY( &b );

			n_paint_grabber_system_set( NULL,NULL, &sx,&sy, NULL,NULL );
		}

		if ( refresh ) { n_paint_grabber_resync_auto(); }
	}

	n_bmp_free( &b );


	if ( refresh ) { n_paint_refresh_all(); }


	n_paint_grabber_status();


	return true;
}

void
n_paint_grabber_dropname( void )
{
//return;

	n_posix_char *dir = n_explorer_cursor2path_new();

	if ( false == n_string_is_empty( dir ) )
	{

		n_posix_char *name;

		if ( n_paint_layer_onoff )
		{
			name = n_string_path_tmpname_new( N_PAINT_EXT_PNG );
		} else {
			name = n_string_path_name_new( n_paint_grbname );
		}

		n_string_path_free( n_paint_grbname );
		n_paint_grbname = n_string_path_make_new( dir, name );
//n_posix_debug_literal( "%s\n%s\n%s", dir, name, n_paint_grbname );

		n_string_path_free( name );

	}

	n_string_path_free( dir );


	return;
}

void
n_paint_grabber_newname( void )
{

	n_posix_char *dir = n_string_path_upperfolder_new( n_paint_bmpname );
	n_posix_char *tmp = n_string_path_tmpname_new( N_PAINT_EXT_NUL );

	n_string_path_free( n_paint_grbname );
	n_paint_grbname = n_string_path_make_new( dir, tmp );

	if ( n_paint_format_is_bmp( n_paint_bmpname ) )
	{
		n_string_path_ext_mod( N_PAINT_EXT_BMP, n_paint_grbname );
	} else
	if ( n_paint_format_is_ico( n_paint_bmpname ) )
	{
		n_string_path_ext_mod( N_PAINT_EXT_ICO, n_paint_grbname );
	} else
	if ( n_paint_format_is_cur( n_paint_bmpname ) )
	{
		n_string_path_ext_mod( N_PAINT_EXT_CUR, n_paint_grbname );
	} else
	if ( n_paint_format_is_jpg( n_paint_bmpname ) )
	{
		n_string_path_ext_mod( N_PAINT_EXT_JPG, n_paint_grbname );
	} else
	if ( n_paint_format_is_png( n_paint_bmpname ) )
	{
		n_string_path_ext_mod( N_PAINT_EXT_PNG, n_paint_grbname );
	} else
	if ( n_paint_format_is_lyr( n_paint_bmpname ) )
	{
		n_string_path_ext_mod( N_PAINT_EXT_LYR, n_paint_grbname );
	} else {
		n_string_path_ext_mod( N_PAINT_EXT_BMP, n_paint_grbname );
	}

	n_string_path_free( dir );
	n_string_path_free( tmp );

//n_posix_debug_literal( "n_paint_grabber_newname() : %s", n_paint_grbname );
	return;
}

#define N_PAINT_GRABBER_LOAD_NEW       0
#define N_PAINT_GRABBER_LOAD_FILE      1
#define N_PAINT_GRABBER_LOAD_CLIPBOARD 2
#define N_PAINT_GRABBER_LOAD_FILL      3
#define N_PAINT_GRABBER_LOAD_FILTER    4

#define n_paint_grabber_new(          ) n_paint_grabber_load( NULL, N_PAINT_GRABBER_LOAD_NEW,       0 )
#define n_paint_grabber_newfile( name ) n_paint_grabber_load( name, N_PAINT_GRABBER_LOAD_FILE,      0 )
#define n_paint_grabber_clipboard(    ) n_paint_grabber_load( NULL, N_PAINT_GRABBER_LOAD_CLIPBOARD, 0 )
#define n_paint_grabber_fill(         ) n_paint_grabber_load( NULL, N_PAINT_GRABBER_LOAD_FILL,      0 )
#define n_paint_grabber_filter(  f    ) n_paint_grabber_load( NULL, N_PAINT_GRABBER_LOAD_FILTER,    f )

// internal
bool
n_paint_grabber_load( n_posix_char *name, int mode, int filter_type )
{

	n_bmp b; n_bmp_zero( &b );


	if ( mode == N_PAINT_GRABBER_LOAD_NEW )
	{

		// [!] : currently unused

		n_bmp_new( &b, N_BMP_SX( n_paint_bmp_data ), N_BMP_SY( n_paint_bmp_data ) );

//n_bmp_flush( &b, n_bmp_rgb( 0, 200, 255 ) );

	} else
	if ( mode == N_PAINT_GRABBER_LOAD_FILE )
	{

		if ( tooltype != N_PAINT_TOOL_TYPE_GRAB )
		{
			if ( N_PAINT_GRABBER_IS_NEUTRAL() )
			{
				return false;
			} else {
				return true;
			}
		}


		n_curico c; n_curico_zero( &c );

		if ( n_paint_load( name, &b, &c ) )
		{

			n_paint_dialog_info( n_project_string_error );

			return true;
		}


		if ( n_paint_layer_onoff )
		{
			int y = n_paint_layer_txtbox.select_cch_y;
			n_paint_bmp_data = &n_paint_layer_data[ y ].bmp_data;
			n_paint_bmp_grab = &n_paint_layer_data[ y ].bmp_grab;
		}

	} else
	if ( mode == N_PAINT_GRABBER_LOAD_CLIPBOARD )
	{

		if ( tooltype != N_PAINT_TOOL_TYPE_GRAB )
		{

			if ( N_PAINT_GRABBER_IS_NEUTRAL() )
			{

				if ( n_clipboard_nbmp_get( &n_paint_layer_data[ 0 ].bmp_data ) ) { return true; }
//n_posix_debug_literal( "1" );


				ShowWindow( hwnd_layr, SW_HIDE );
				n_paint_layer_reset();


				n_paint_grabber_reset();


				n_string_path_free( n_paint_bmpname );

				n_paint_bmpname = n_paint_newname_new();
				n_string_path_ext_mod( N_PAINT_EXT_PNG, n_paint_bmpname );


				n_paint_refresh_all();

				n_paint_title();
				n_paint_tool_saveicon_refresh();


				return false;

			} else {
//n_posix_debug_literal( "2" );

				return true;

			}

		} else {

			if ( n_clipboard_nbmp_get( &b ) ) { return true; }

		}

//n_bmp_free( &b ); return true;

	} else
	if ( mode == N_PAINT_GRABBER_LOAD_FILL )
	{

		if ( tooltype == N_PAINT_TOOL_TYPE_GRAB ) { return true; }

		bool ret = n_paint_layer_bmp_fill( &b );
		if ( ret ) { return ret; }

	} else
	if ( mode == N_PAINT_GRABBER_LOAD_FILTER )
	{

		//bool is_scaler = ( ( filter_type == N_PAINT_FILTER_SCALE_LIL )||( filter_type == N_PAINT_FILTER_SCALE_BIG ) );

		if ( N_PAINT_GRABBER_IS_NEUTRAL() )
		{

			if ( n_paint_layer_onoff )
			{

				int i = 0;
				while( 1 )
				{
					// [!] : see grabber_select()
					//if ( ( is_scaler )||( n_paint_layer_data[ i ].visible ) )
					{
						n_paint_filter_go( &n_paint_layer_data[ i ].bmp_data, filter_type );
					}

					i++;
					if ( i >= n_paint_layer_count ) { break; }
				}

			} else {

				n_paint_filter_go( n_paint_bmp_data, filter_type );

			}

			n_paint_refresh_all();

			return false;
		}

		if ( filter_type == N_PAINT_FILTER_CLEAR )
		{

			n_paint_grabber_clear();

			return false;
		}

		if ( n_paint_grabber_wholegrb_onoff )
		{
//n_win_debug_count( hwnd_layr );

			n_bmp *p_data = n_paint_bmp_data;
			n_bmp *p_grab = n_paint_bmp_grab;

			int i = 0;
			while( 1 )
			{
				// [!] : see grabber_select()
				//if ( ( is_scaler )||( n_paint_layer_data[ i ].visible ) )
				{
					n_paint_bmp_grab = &n_paint_layer_data[ i ].bmp_grab;

					bool calc = false;
					if ( n_paint_bmp_grab == &n_paint_layer_data[ n_paint_grabber_selected_index ].bmp_grab )
					{
						calc = true;
					}

					if ( tooltype == N_PAINT_TOOL_TYPE_GRAB )
					{
						calc = false;
					} else {
						n_paint_bmp_data = &n_paint_layer_data[ i ].bmp_data;
					}

					n_paint_grabber_filter_sync( filter_type, calc, false );
				}

				i++;
				if ( i >= n_paint_layer_count ) { break; }
			}

			n_paint_bmp_data = p_data;
			n_paint_bmp_grab = p_grab;

			n_paint_refresh_all();

			return false;

		} else
		if ( n_paint_layer_onoff )
		{

			n_bmp_carboncopy( n_paint_bmp_grab, &b );
			n_paint_filter_go( &b, filter_type );

		} else {

			if ( tooltype == N_PAINT_TOOL_TYPE_GRAB )
			{
				n_bmp_carboncopy( n_paint_bmp_grab, &b );
				n_paint_filter_go( &b, filter_type );
			} else {
				return n_paint_grabber_filter_sync( filter_type, true, true );
			}

		}

	} else { return false; }


	grabber = N_PAINT_GRABBER_DRAG_OK;


	s32 x,y,sx,sy,fx,fy; n_paint_grabber_system_get( &x,&y, &sx,&sy, &fx,&fy );

	if ( mode == N_PAINT_GRABBER_LOAD_NEW )
	{

		x = y = fx = fy = 0;

	} else
	if ( mode == N_PAINT_GRABBER_LOAD_FILE )
	{

		if ( hwnd_main == n_win_cursor2hwnd() )
		{

			s32 bmpsx = N_BMP_SX( &b );
			s32 bmpsy = N_BMP_SY( &b );


			n_paint_canvaspos( &x, &y );

			x -= bmpsx / 2;
			y -= bmpsy / 2;

			if ( ( x + bmpsx ) >= nwin_main.csx ) { x = nwin_main.csx - bmpsx; }
			if ( ( y + bmpsy ) >= nwin_main.csy ) { y = nwin_main.csy - bmpsy; }

			if ( x < 0 ) { x = 0; }
			if ( y < 0 ) { y = 0; }

		} else {

			x = y = 0;

		}

		fx = x;
		fy = y;

	} else
	if ( mode == N_PAINT_GRABBER_LOAD_CLIPBOARD )
	{

		x = y = fx = fy = 0;

	} else
	if ( mode == N_PAINT_GRABBER_LOAD_FILL )
	{

		//

	} else
	if ( mode == N_PAINT_GRABBER_LOAD_FILTER )
	{

		//

	}

	n_paint_grabber_system_set( &x,&y, &sx,&sy, &fx,&fy );


	n_paint_grabber_select( &b, true );


	// [Patch] : WM_PAINT doesn't come when dropped

	if ( mode == N_PAINT_GRABBER_LOAD_FILE ) { n_paint_refresh_client(); }


	n_bmp_free( &b );


	n_paint_grabber_status();


	if ( mode == N_PAINT_GRABBER_LOAD_NEW )
	{
		n_paint_grabber_newname();
	} else
	if ( mode == N_PAINT_GRABBER_LOAD_FILE )
	{
		n_string_path_free( n_paint_grbname );
		n_paint_grbname = n_string_path_carboncopy( name );
	} else
	if ( mode == N_PAINT_GRABBER_LOAD_CLIPBOARD )
	{
		n_paint_grabber_newname();
	} else
	if ( mode == N_PAINT_GRABBER_LOAD_FILL )
	{
		//
	} else
	if ( mode == N_PAINT_GRABBER_LOAD_FILTER )
	{
		//
	}
//n_posix_debug_literal( "%s\n%s", name, n_paint_grbname );


	if ( n_paint_layer_onoff )
	{
		n_paint_grabber_selected_index = n_paint_layer_txtbox.select_cch_y;
	}


	return true;
}

// internal
void
n_paint_grabber_pixel_get( n_bmp *grab, s32 tx, s32 ty, u32 picked, u32 *before, u32 *after, double blend )
{

	u32 color_b, color_a;


	// [x] : don't use _fast()

	if ( N_PAINT_GRABBER_IS_NEUTRAL() )
	{

		//n_bmp_ptr_get( n_paint_bmp_data, tx,ty, &color_b );

		color_b = n_bmp_antialias_pixel( n_paint_bmp_data, tx,ty, blend );
		color_a = picked;

	} else {

		s32 x,y,sx,sy; n_paint_grabber_system_get( &x,&y, &sx,&sy, NULL,NULL );


		s32 gx = tx - x;
		s32 gy = ty - y;

		if ( n_bmp_ptr_is_accessible( grab, gx,gy ) )
		{
			//n_bmp_ptr_get_fast(             grab, gx,gy, &color_b );
			color_b = n_bmp_antialias_pixel(             grab, gx,gy, blend );
		} else {
			//n_bmp_ptr_get     ( n_paint_bmp_data, tx,ty, &color_b );
			color_b = n_bmp_antialias_pixel( n_paint_bmp_data, tx,ty, blend );
		}


		// [!] : Eraser

		if ( N_BMP_ALPHA_CHANNEL_INVISIBLE == n_bmp_a( picked ) )
		//if ( false )
		{
			n_bmp_ptr_get( n_paint_bmp_data, tx,ty, &color_a );
		} else {
			color_a = picked;
		}

	}


	if ( before != NULL ) { (*before) = color_b; }
	if ( after  != NULL ) { (*after ) = color_a; }


	return;
}

// internal
void
n_paint_grabber_pixel_set( s32 tx, s32 ty, u32 before, u32 after )
{

	if ( before == after ) { return; }


	if ( N_PAINT_GRABBER_IS_NEUTRAL() )
	{

		n_bmp_ptr_set( n_paint_bmp_data, tx,ty, after );

	} else {

		s32 x,y,sx,sy; n_paint_grabber_system_get( &x,&y, &sx,&sy, NULL,NULL );

/*
		int a = n_bmp_a( before );

		if ( a == N_BMP_ALPHA_CHANNEL_INVISIBLE )
		{
			n_bmp_ptr_get( n_paint_bmp_data, tx,ty, &after );
		}
*/

		s32 grab_x = tx - x;
		s32 grab_y = ty - y;

		n_bmp_ptr_set( n_paint_bmp_grab, grab_x,grab_y, after );

	}


	return;
}

// internal
u32
n_paint_grabber_colorpicker( void )
{

	u32 color = n_bmp_white_invisible;


	s32 mx,my; n_paint_margin_get( &mx, &my );
	s32 sx = nwin_main.csx - ( mx * 2 );
	s32 sy = nwin_main.csy - ( my * 2 );

	if ( n_win_is_hovered_offset( hwnd_main, mx,my,sx,sy ) )
	{
//n_win_hwndprintf_literal( hwnd_main, " In " );
		s32 x,y; n_paint_canvaspos( &x,&y );
		n_paint_grabber_pixel_get( n_paint_bmp_grab, x,y, 0, &color, NULL, 0.0 );
	} else {
//n_win_hwndprintf_literal( hwnd_main, " Out " );
		color = n_paint_tool_color_transparent_get();
	}


	return color;
}

void
n_paint_grabber_cursor_automove( s32 x, s32 y, s32 sx, s32 sy )
{

	s32 cursor_x = ( x + sx );
	s32 cursor_y = ( y + sy );

	{
		s32 cur_x, cur_y;
		n_win_cursor_position_relative( hwnd_main, &cur_x, &cur_y ); 
		n_paint_canvaspos( &cur_x, &cur_y );

		if ( cur_x < ( x + ( sx / 2 ) ) ) { cursor_x = x; } 
		if ( cur_y < ( y + ( sy / 2 ) ) ) { cursor_y = y; } 
	}


	int z = n_paint_zoom_get( zoom );

	if ( n_paint_is_zoom_in( zoom ) )
	{
		cursor_x *= z;
		cursor_y *= z;
	} else
	if ( n_paint_is_zoom_out( zoom ) )
	{
		cursor_x /= z;
		cursor_y /= z;
	}


	s32 margin_sx,margin_sy; n_paint_margin_get( &margin_sx, &margin_sy );

	POINT p;
	p.x = margin_sx + cursor_x - nwin_main.scrollx;
	p.y = margin_sy + cursor_y - nwin_main.scrolly;
	ClientToScreen( hwnd_main, &p );
	SetCursorPos( p.x, p.y );



	return;
}

void
n_paint_grabber_select_all( void )
{

	int i = 0;
	while( 1 )
	{
		n_bmp_free( &n_paint_layer_data[ i ].bmp_grab );

		i++;
		if ( i >= n_paint_layer_count ) { break; }
	}

	n_paint_grabber_init();

	if ( n_paint_grabber_wholegrb_onoff )
	{

		s32  x = 0;
		s32  y = 0;
		s32 sx = N_BMP_SX( &n_paint_layer_data[ 0 ].bmp_data );
		s32 sy = N_BMP_SY( &n_paint_layer_data[ 0 ].bmp_data );

		int i = 0;
		while( 1 )
		{

			if ( n_paint_layer_data[ i ].visible )
			{
				n_bmp_new_fast( &n_paint_layer_data[ i ].bmp_grab, sx,sy );
				n_bmp_fastcopy( &n_paint_layer_data[ i ].bmp_data, &n_paint_layer_data[ i ].bmp_grab, x,y,sx,sy, 0,0 );
			} else {
				n_bmp_new( &n_paint_layer_data[ i ].bmp_grab, sx,sy );
			}

			i++;
			if ( i >= n_paint_layer_count ) { break; }
		}

		n_paint_grabber_system_set( &x,&y,&sx,&sy, 0,0 );

	} else {

		n_paint_grabber_select( n_paint_bmp_data, true );

	}


	n_paint_status();


	grabber = N_PAINT_GRABBER_DRAG_OK;
	n_paint_grabber_status();


	n_paint_layer_grabber_location( n_paint_layer_txtbox.select_cch_y );


	return;
}

void
n_paint_grabber_copy( void )
{

	s32 x,y,fx,fy; n_paint_grabber_system_get( &x,&y, NULL,NULL, &fx,&fy );

	n_bmp_flush( n_paint_bmp_grab, n_bmp_white_invisible );
	n_paint_grabber_select( NULL, false );

	fx = x;
	fy = y;

	n_paint_grabber_system_set( &x,&y, NULL,NULL, &fx,&fy );
	n_paint_grabber_status();

	n_paint_grabber_resync_auto();


	return;
}

void
n_paint_grabber_paste( void )
{

	// [Needed] : n_bmp_flush() for out-of-bound

	n_paint_grabber_composition( n_paint_bmp_grab, n_paint_bmp_data, true, false );
	n_bmp_flush( n_paint_bmp_grab, n_bmp_white_invisible );

	n_paint_grabber_select( NULL, false );

	n_paint_grabber_resync_auto();


	return;
}

bool
n_paint_grabber_proc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam, bool is_directcall )
{

	// [Mechanism]
	//
	//	[ DRAGGING ]
	//
	//	drag_ox/_oy      : offset from top-left
	//	drag_fx/_fy      : for reverse selection like bottom-right to top-left
	//
	//
	//	[ STRETCH_* ]
	//
	//	stretch_bmp      : a temporary buffer
	//	stretch_sx/_sy   : original size
	//	stretch_ox/_oy   :  center position
	//	stretch_px/_py   : restore position
	//	stretch_ratio    : for STRETCH_PROPORTIONAL


	if ( n_paint_vscr.drag_onoff ) { return false; }
	if ( n_paint_hscr.drag_onoff ) { return false; }


	if ( n_paint_on_setcursor_condition() )
	{
		if ( N_PAINT_GRABBER_IS_NEUTRAL() )
		{
			return n_paint_on_setcursor( hwnd, msg, wparam, lparam );
		}
	}


	static s32     drag_ox       = 0;
	static s32     drag_oy       = 0;
	static s32     drag_fx       = 0;
	static s32     drag_fy       = 0;

	static n_bmp  *stretch_bmp;
	static s32     stretch_fx    = 0;
	static s32     stretch_fy    = 0;
	static s32     stretch_sx    = 0;
	static s32     stretch_sy    = 0;
	static s32     stretch_ox    = 0;
	static s32     stretch_oy    = 0;
	static s32     stretch_px    = 0;
	static s32     stretch_py    = 0;
	static double  stretch_ratio = 0;

	static s32     p_cursor_x    = 0;
	static s32     p_cursor_y    = 0;


	// [!] : grabber : OFF

	if ( tooltype != N_PAINT_TOOL_TYPE_GRAB ) { return false; }


	switch( msg ) {


	case WM_LBUTTONDBLCLK :

//n_win_hwndprintf_literal( hwnd, "%d", grabber );


		if ( N_PAINT_GRABBER_IS_NEUTRAL() )
		{
//n_win_text_set_literal( hwnd, "Grabber : NEUTRAL : WM_LBUTTONDBLCLK" );


			// [ Mechanism ]
			//
			//	# : WM_*             : grabber   : size
			//	1 : WM_LBUTTONDOWN   : SELECTING : 0 0
			//	2 : WM_LBUTTONUP     : NEUTRAL   : 0 0
			//	3 : WM_LBUTTONDBLCLK : NEUTRAL   : 0 0


			n_paint_grabber_select_all();

		} else

		if ( N_PAINT_GRABBER_IS_DRAG_OK() )
		{
//n_win_text_set_literal( hwnd, "Grabber : DRAG_OK : WM_LBUTTONDBLCLK" );

			n_paint_grabber_position_reset();

		}


	break;

	case WM_LBUTTONDOWN :


		if ( is_directcall == false ) { SetCapture( hwnd ); }


		n_win_cursor_position_relative( hwnd_main, &p_cursor_x, &p_cursor_y );


		if ( N_PAINT_GRABBER_IS_NEUTRAL() )
		{
//n_win_text_set_literal( hwnd, "Grabber : NEUTRAL : WM_LBUTTONDOWN" );


			s32 x,y,sx,sy,fx,fy; n_paint_grabber_system_get( &x,&y, &sx,&sy, &fx,&fy );

			{

				const s32 maxsx = N_BMP_SX( n_paint_bmp_data ) - 1;
				const s32 maxsy = N_BMP_SY( n_paint_bmp_data ) - 1;

				n_paint_canvaspos( &x, &y );

				if ( x < 0 ) { x = 0; } else if ( x > maxsx ) { x = maxsx; }
				if ( y < 0 ) { y = 0; } else if ( y > maxsy ) { y = maxsy; }

			}


			drag_fx = fx = x;
			drag_fy = fy = y;

			sx = sy = 0;

			n_paint_grabber_system_set( &x,&y, &sx,&sy, &fx,&fy );


			n_paint_grabber_newname();


			n_paint_grabber_selected_index = n_paint_layer_txtbox.select_cch_y;

			n_paint_bmp_grab = &n_paint_layer_data[ n_paint_grabber_selected_index ].bmp_grab;


			grabber = N_PAINT_GRABBER_SELECTING;

		} else

		if ( N_PAINT_GRABBER_IS_DRAG_OK() )
		{
//n_win_text_set_literal( hwnd, "Grabber : DRAG_OK : WM_LBUTTONDOWN" );


			// Phase 1 : starting position and size

			s32 x,y,sx,sy,fx,fy; n_paint_grabber_system_get( &x,&y, &sx,&sy, &fx,&fy );


			// Phase 2 : switching to DnD mode

			s32 canvas_x,canvas_y;
			n_paint_canvaspos( &canvas_x, &canvas_y );

			if (
				( canvas_x < x )||( canvas_x >= ( x + sx ) )
				||
				( canvas_y < y )||( canvas_y >= ( y + sy ) )
			)
			{
				if ( is_directcall == false ) { break; }
			}

//n_win_text_set_literal( hwnd, "Selected" );

			if ( false == n_win_is_input( VK_CONTROL ) )
			{

				grabber = N_PAINT_GRABBER_DRAGGING;

				drag_ox = canvas_x - x;
				drag_oy = canvas_y - y;

			} else {

				if ( n_win_is_input( VK_SHIFT ) )
				{
					grabber = N_PAINT_GRABBER_STRETCH_TRANSFORM;
				} else {
					grabber = N_PAINT_GRABBER_STRETCH_PROPORTIONAL;
					stretch_ratio = (double) sx / sy;
				}


				// [!] : Backup

				if ( n_paint_grabber_wholegrb_onoff )
				{
					stretch_bmp = n_memory_new( sizeof( n_bmp ) * n_paint_layer_count );

					int i = 0;
					while( 1 )
					{
						n_bmp_carboncopy( &n_paint_layer_data[ i ].bmp_grab, &stretch_bmp[ i ] );
						i++;
						if ( i >= n_paint_layer_count ) { break; }
					}
				} else
				if ( n_paint_layer_onoff )
				{
					stretch_bmp = n_memory_new( sizeof( n_bmp ) );
					n_bmp_carboncopy( n_paint_bmp_grab, stretch_bmp );
				} else {
					stretch_bmp = n_memory_new( sizeof( n_bmp ) );
					n_bmp_carboncopy( n_paint_bmp_grab, stretch_bmp );
				}

				stretch_px = x;
				stretch_py = y;


				// [!] : Init

				stretch_sx = sx;
				stretch_sy = sy;
				stretch_ox =  x + ( stretch_sx / 2 );
				stretch_oy =  y + ( stretch_sy / 2 );

				if ( is_directcall == false )
				{
					n_paint_grabber_cursor_automove( x,y, sx,sy );
				}

				n_paint_canvaspos( &stretch_fx, &stretch_fy );

				n_paint_grabber_status();

			}

		}

	break;

	case WM_MOUSEMOVE :


		// [!] : for VirtualPC

		{
			s32 cursor_x, cursor_y;
			n_win_cursor_position_relative( hwnd_main, &cursor_x, &cursor_y );

			if ( ( p_cursor_x == cursor_x )&&( p_cursor_y == cursor_y ) )
			{
				break;
			}
		}


		if ( N_PAINT_GRABBER_IS_SELECTING() )
		{
//n_win_text_set_literal( hwnd, "Grabber : WM_MOUSEMOVE : WM_MOUSEMOVE" );

			// Phase 1 : init

			s32 x,y,sx,sy,fx,fy; n_paint_grabber_system_get( &x,&y, &sx,&sy, &fx,&fy );

			{

				const s32 maxsx = N_BMP_SX( n_paint_bmp_data ) - 1;
				const s32 maxsy = N_BMP_SY( n_paint_bmp_data ) - 1;

				n_paint_canvaspos( &x, &y );

				if ( x < 0 ) { x = 0; } else if ( x > maxsx ) { x = maxsx; }
				if ( y < 0 ) { y = 0; } else if ( y > maxsy ) { y = maxsy; }

			}


			// Phase 2 : size : +1 for including outer

			sx = abs( drag_fx - x ) + 1;
			sy = abs( drag_fy - y ) + 1;


			// Phase 3 : position : top-left

			fx = x = n_posix_min_s32( drag_fx, x );
			fy = y = n_posix_min_s32( drag_fy, y );


			n_paint_grabber_system_set( &x,&y, &sx,&sy, &fx,&fy );


			n_paint_grabber_select( NULL, true );


			n_paint_layer_grabber_onoff( false );

		} else

		if ( N_PAINT_GRABBER_IS_DRAGGING() )
		{
//n_win_text_set_literal( hwnd, "Grabber : DRAGGING : WM_MOUSEMOVE" );


			s32 x,y,sx,sy,fx,fy; n_paint_grabber_system_get( &x,&y, &sx,&sy, &fx,&fy );

			n_paint_canvaspos( &x, &y );

			x -= drag_ox;
			y -= drag_oy;

			n_paint_grabber_system_set( &x,&y, &sx,&sy, &fx,&fy );


			n_paint_grabber_resync_auto();

		} else

		if ( ( N_PAINT_GRABBER_IS_STRETCH_PROPORTIONAL() )||( N_PAINT_GRABBER_IS_STRETCH_TRANSFORM() ) )
		{
//n_win_text_set_literal( hwnd, "Grabber : STRETCHING : WM_MOUSEMOVE" );


			// Phase 1 : init

			s32 x,y,sx,sy; n_paint_grabber_system_get( &x,&y, NULL,NULL, NULL,NULL );


			// [!] : don't clip for usability

			n_paint_canvaspos( &x, &y );

			if ( ( stretch_fx == x )&&( stretch_fy == y ) ) { break; }

			stretch_fx = x;
			stretch_fy = y;


			// Phase 2 : size

			if ( N_PAINT_GRABBER_IS_STRETCH_PROPORTIONAL() )
			{
				sy = ( abs( stretch_oy - y ) * 2 );
				sx = (double) sy * stretch_ratio;
			} else {
				sx = ( abs( stretch_ox - x ) * 2 );
				sy = ( abs( stretch_oy - y ) * 2 );
			}

			if ( sx == 0 ) { sx = 1; }
			if ( sy == 0 ) { sy = 1; }

//n_win_hwndprintf_literal( hwnd, "%d : %d", (int) sx, (int) sy );


			// Phase 3 : position

			x = stretch_ox - ( sx / 2 );
			y = stretch_oy - ( sy / 2 );


			n_paint_grabber_system_set( &x,&y, &sx,&sy, NULL,NULL );


			{ // n_paint_grabber_transform()

			double ratio_x = (double) sx / stretch_sx;
			double ratio_y = (double) sy / stretch_sy;

			if ( ( ratio_x * stretch_sx ) == 0 ) { break; }
			if ( ( ratio_y * stretch_sy ) == 0 ) { break; }

			if ( n_paint_grabber_wholegrb_onoff )
			{

				int i = 0;
				while( 1 )
				{
					// [!] : see grabber_select()
					//if ( n_paint_layer_data[ i ].visible )
					{
						n_bmp b; n_bmp_carboncopy( &stretch_bmp[ i ], &b );

						n_bmp_resampler( &b, ratio_x,ratio_y );

//n_paint_grabber_select( &b, true );

						n_bmp_free_fast( &n_paint_layer_data[ i ].bmp_grab );
						n_bmp_carboncopy( &b, &n_paint_layer_data[ i ].bmp_grab );

						sx = N_BMP_SX( &b );
						sy = N_BMP_SY( &b );

						n_bmp_free_fast( &b );
					}

					i++;
					if ( i >= n_paint_layer_count ) { break; }
				}

				n_paint_grabber_system_set( &x,&y, &sx,&sy, NULL,NULL );
				n_paint_grabber_resync_auto();

			} else
			if ( n_paint_layer_onoff )
			{

				n_bmp b; n_bmp_carboncopy( stretch_bmp, &b );

				n_bmp_resampler( &b, ratio_x,ratio_y );
				n_paint_grabber_select( &b, true );

				n_bmp_free( &b );

			} else {

				n_bmp b; n_bmp_carboncopy( stretch_bmp, &b );

				n_bmp_resampler( &b, ratio_x,ratio_y );
				n_paint_grabber_select( &b, true );

				n_bmp_free( &b );

			}

			} // n_paint_grabber_transform()

		}// else


		n_paint_status();
		n_paint_grabber_status();

	break;

	case WM_LBUTTONUP :

		ReleaseCapture();

		if ( N_PAINT_GRABBER_IS_SELECTING() )
		{
//n_win_text_set_literal( hwnd, "Grabber : SELECTING : WM_LBUTTONUP" );


			s32 x,y,sx,sy,fx,fy; n_paint_grabber_system_get( &x,&y, &sx,&sy, &fx,&fy );

//n_win_hwndprintf_literal( hwnd, "%d : %d", (int) sx, (int) sy );


			if ( ( sx <= 0 )&&( sy <= 0 ) )
			{

				grabber = N_PAINT_GRABBER_NEUTRAL;

				break;
			}


			// position : use the last position
			// size     : use the last size


			grabber = N_PAINT_GRABBER_DRAG_OK;


			n_paint_layer_grabber_onoff( false );
			n_paint_layer_grabber_location( n_paint_layer_txtbox.select_cch_y );

		} else

		if ( N_PAINT_GRABBER_IS_DRAGGING() )
		{
//n_win_text_set_literal( hwnd, "Grabber : DRAGGING : WM_LBUTTONUP" );

			grabber = N_PAINT_GRABBER_DRAG_OK;

			if ( n_win_is_hovered( hwnd_main ) )
			{
				break;
			}

			if ( n_win_is_hovered( hwnd_tool ) )
			{
				n_paint_grabber_position_reset();
				n_paint_grabber_status();

				break;
			}

			if ( n_win_is_hovered( hwnd_layr ) )
			{
				n_paint_grabber_position_reset();
				n_paint_grabber_status();

				break;
			}

			n_paint_grabber_dropname();

			n_paint_formatter_name = n_paint_grbname;

			if (
				( n_paint_layer_onoff            == false )
				||
				( n_paint_grabber_wholegrb_onoff == false )
			)
			{
				n_paint_formatter_bmp = n_paint_bmp_grab;
			} else {
				s32 bmpsx = N_BMP_SX( &n_paint_layer_data[ 0 ].bmp_data );
				s32 bmpsy = N_BMP_SY( &n_paint_layer_data[ 0 ].bmp_data );

				n_bmp_new( &n_paint_layer_as_one, bmpsx, bmpsy );
				n_bmp_layercopy( n_paint_layer_data, &n_paint_layer_as_one, 0,0,bmpsx,bmpsy, 0,0, false );

				n_paint_formatter_bmp = &n_paint_layer_as_one;
			}

			n_win_gui( hwnd_main, WINDOW, n_paint_formatter_wndproc, &n_paint_hpopup );

		} else

		if ( ( N_PAINT_GRABBER_IS_STRETCH_PROPORTIONAL() )||( N_PAINT_GRABBER_IS_STRETCH_TRANSFORM() ) )
		{
//n_win_text_set_literal( hwnd, "Grabber : STRETCHING : WM_LBUTTONUP" );


			bool ret = n_paint_dialog_yesno( n_project_string_really_ok );
			if ( ret )
			{

				s32 x,y,sx,sy,fx,fy; n_paint_grabber_system_get( &x,&y, &sx,&sy, &fx,&fy );

				fx = x;
				fy = y;

				n_paint_grabber_system_set( &x,&y, &sx,&sy, &fx,&fy );

			} else {

				// [!] : reselect an area before stretching

				s32 x,y,sx,sy,fx,fy; n_paint_grabber_system_get( &x,&y, &sx,&sy, &fx,&fy );

				x = stretch_px;
				y = stretch_py;

				n_paint_grabber_system_set( &x,&y, &sx,&sy, &fx,&fy );


				if ( n_paint_grabber_wholegrb_onoff )
				{

					int i = 0;
					while( 1 )
					{
						// [!] : see grabber_select()
						//if ( n_paint_layer_data[ i ].visible )
						{
							n_bmp_free( &n_paint_layer_data[ i ].bmp_grab );
							n_bmp_carboncopy( &stretch_bmp[ i ], &n_paint_layer_data[ i ].bmp_grab );

							sx = N_BMP_SX( &n_paint_layer_data[ i ].bmp_grab );
							sy = N_BMP_SY( &n_paint_layer_data[ i ].bmp_grab );
						}

						i++;
						if ( i >= n_paint_layer_count ) { break; }
					}

					n_paint_grabber_system_set( &x,&y, &sx,&sy, NULL,NULL );
					n_paint_grabber_resync_auto();

				} else
				if ( n_paint_layer_onoff )
				{

					n_paint_grabber_select( stretch_bmp, true );

				} else {

					n_paint_grabber_select( stretch_bmp, true );

				}

			}


			if ( n_paint_grabber_wholegrb_onoff )
			{
				int i = 0;
				while( 1 )
				{
					n_bmp_free( &stretch_bmp[ i ] );
					i++;
					if ( i >= n_paint_layer_count ) { break; }
				}
			} else
			if ( n_paint_layer_onoff )
			{
				n_bmp_free( stretch_bmp );
			} else {
				n_bmp_free( stretch_bmp );
			}

			n_memory_free( stretch_bmp );


			grabber = N_PAINT_GRABBER_DRAG_OK;

		}

	break;

	case WM_RBUTTONDOWN :

		if ( N_PAINT_GRABBER_IS_DRAG_OK() )
		{
//n_win_text_set_literal( hwnd, "Grabber : DRAG_OK : WM_RBUTTONDOWN" );


			n_paint_grabber_finish();

		}

	break;


	} // switch


	return false;
}

