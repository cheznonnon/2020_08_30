// Nonnon Mail Manager
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#include "../nonnon/neutral/txt.c"


#include "../nonnon/win32/win_listview.c"




void
n_listview_gui( HWND hwnd_parent, HWND *hgui )
{

	if ( hgui == NULL ) { return; }


	n_win_listview_gui
	(
		hwnd_parent, hgui,
		  LVS_REPORT
		| LVS_AUTOARRANGE  | LVS_SORTASCENDING
		| LVS_SHOWSELALWAYS
		,
		  LVS_EX_CHECKBOXES | LVS_EX_FULLROWSELECT
		| LVS_EX_GRIDLINES | LVS_EX_HEADERDRAGDROP
	);


	return;
}

void
n_listview_sort( n_txt *p, int updown )
{

	// [!] : this module is based on n_vector_sort()


	// [!] : updown
	//
	//	-1 : down / descending / decremental : c b a
	//	+1 : up   /  ascending / incremental : a b c


	if ( n_txt_error( p ) ) { return; }


	// [!] : nothing to do

	if ( 1 >= p->sy ) { return; }
	if ( updown == 0 ) { return; }


	if ( updown > 0 ) { updown =  1; } else
	if ( updown < 0 ) { updown = -1; }


	// [!] : zero is reserved for checkbox

	int i  = 1;
	int ii = i + 1;
	while( 1 )
	{//break;

		n_posix_char *str1 = n_string_new( n_posix_strlen( p->line[  i ] ) ); 
		n_posix_char *str2 = n_string_new( n_posix_strlen( p->line[ ii ] ) ); 

		n_string_parameter( p->line[  i ], N_STRING_COMMA, N_STRING_EMPTY, 0, str1 );
		n_string_parameter( p->line[ ii ], N_STRING_COMMA, N_STRING_EMPTY, 0, str2 );

		if ( updown == n_posix_strcmp( str1, str2 ) )
		{
			n_txt_swap( p, i, ii );
		}

		n_string_free( str1 );
		n_string_free( str2 );


		ii++;
		if ( ii >= p->sy )
		{

			i++;
			if (  i >= p->sy ) { break; }

			ii = i + 1;
			if ( ii >= p->sy ) { break; }

		}
	}


	return;
}

bool
n_listview_load( HWND hgui, n_posix_char *cmdline )
{

	n_txt txt; n_txt_zero( &txt );	
	if ( n_txt_load( &txt, cmdline ) ) { return true; }


	n_ini ini; n_ini_zero( &ini ); n_ini_load( &ini, N_MAILMANAGER_INI_NAME );

	bool autoheader = n_ini_value_int
	(
		&ini,
		N_MAILMANAGER_INI_SECT,
		n_posix_literal( "autoheader" ),
		0
	);

	n_ini_free( &ini );


	// [Needed] : for data integrity

	int max_sx = 0;

	{

		int sy = txt.sy;
		int  y = sy - 1;
		while( 1 )
		{

			if ( y < 0 ) { break; }


			int sx = n_string_parameter_count( txt.line[ y ], N_STRING_COMMA, N_STRING_EMPTY );

			if ( sx == 0 ) { n_txt_del( &txt, y ); }

			if ( max_sx < sx ) { max_sx = sx; }


			y--;

		}

		if ( ( txt.sy == 1 )&&( n_string_is_empty( n_txt_get( &txt, 0 ) ) ) )
		{

			n_txt_free( &txt );

			return false;
		}

	}

	n_listview_sort( &txt, 1 );


	// [!] : loading start

	n_win_redraw_off( hgui );

	if ( autoheader )
	{

		// [Needed] : parent items first

		n_win_listview_header_set_literal( hgui, 0, "0" );

		int y = 0;
		while( 1 )
		{//break;

			if ( y >= txt.sy ) { break; }


			n_win_listview_item_set_literal( hgui, 0,y, "" );


			y++;

		}

		int x = 0;
		while( 1 )
		{//break;

			if ( x >= max_sx ) { break; }


			n_posix_char str[ N_WIN_LISTVIEW_CCH ];
			n_posix_sprintf_literal( str, "%d", x+1 );

			n_win_listview_header_set( hgui, x+1, str );


			x++;

		}

		y = 0;
		while( 1 )
		{//break;

			if ( y >= txt.sy ) { break; }


			int x = 0;
			while( 1 )
			{

				if ( x >= max_sx ) { break; }


				n_posix_char str[ N_WIN_LISTVIEW_CCH ];
				n_string_parameter( txt.line[ y ], N_STRING_COMMA, N_STRING_EMPTY, x, str );

				n_win_listview_item_set( hgui, x+1,y, str );


				x++;

			}


			y++;

		}

	} else {

		// [Needed] : parent items first

		int y = 0;
		while( 1 )
		{//break;

			if ( y >= txt.sy ) { break; }


			if ( y == 0 )
			{
				n_win_listview_header_set_literal( hgui, 0, "" );
			} else {
				n_win_listview_item_set_literal( hgui, 0,y, "" );
			}


			y++;

		}

		y = 0;
		while( 1 )
		{//break;

			if ( y >= txt.sy ) { break; }


			int x = 0;
			while( 1 )
			{

				if ( x >= max_sx ) { break; }


				n_posix_char str[ N_WIN_LISTVIEW_CCH ];
				n_string_parameter( txt.line[ y ], N_STRING_COMMA, N_STRING_EMPTY, x, str );

				if ( y == 0 )	
				{
					n_win_listview_header_set( hgui, x+1, str );
				} else {
					n_win_listview_item_set( hgui, x+1,y-1, str );
				}


				x++;

			}


			y++;

		}

	}


	n_txt_free( &txt );


	// [!] : after loading

	n_win_listview_header_sort_all( hgui, 1, n_HDF_SORTUP );

	n_win_listview_header_adjust( hgui );


	// [Needed] : after n_win_listview_header_adjust()

	n_win_listview_header_checkbox( hgui, 0 );


	return false;
}


