// hunyapiyo2
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef N_GAMECONSOLE

#include "../nonnon/project/define_unicode.c"

#endif // #ifdef N_GAMECONSOLE




#include "../nonnon/game/timegettime.c"

#include "../nonnon/game/game.c"

#include "../nonnon/game/chara.c"
#include "../nonnon/game/click.c"
#include "../nonnon/game/rc.c"
#include "../nonnon/game/sound.c"
#include "../nonnon/game/progressbar.c"
#include "../nonnon/game/transition.c"

#include "../nonnon/win32/gdi.c"

#include "../nonnon/project/macro.c"




// Constants

#ifndef N_GAMECONSOLE

#define N_GAMECONSOLE_ICON_OFFSET_HUNYAPIYO2 ( 0 )

#endif // #ifndef N_GAMECONSOLE


#define HUNYAPIYO2_WAV_2     "N_PROJECT_SOUND_GET"


#define N_HUNYAPIYO2_BMP_ALL 5
#define N_HUNYAPIYO2_WAV_ALL 3

#define N_HUNYAPIYO2_MAP_SX  7
#define N_HUNYAPIYO2_MAP_SY  7
#define N_HUNYAPIYO2_MAP_ALL ( N_HUNYAPIYO2_MAP_SX * N_HUNYAPIYO2_MAP_SY )


#define N_HUNYAPIYO2_NONE    0
#define N_HUNYAPIYO2_CLICKED 1
#define N_HUNYAPIYO2_HILIGHT 2
#define N_HUNYAPIYO2_CHAINED 3
#define N_HUNYAPIYO2_LOCKED  4


#define N_HUNYAPIYO2_PHASE_FIRST -1
#define N_HUNYAPIYO2_PHASE_START  0
#define N_HUNYAPIYO2_PHASE_LOOP1  1
#define N_HUNYAPIYO2_PHASE_SCORE  2
#define N_HUNYAPIYO2_PHASE_SLEEP  3
#define N_HUNYAPIYO2_PHASE_LOOP2  4
#define N_HUNYAPIYO2_PHASE_RESET  5
#define N_HUNYAPIYO2_PHASE_STOP   6




// Instance

typedef struct {

	n_bmp          bmp[ N_HUNYAPIYO2_BMP_ALL ];
	n_game_sound   snd[ N_HUNYAPIYO2_WAV_ALL ];
	n_game_chara   chr[ N_HUNYAPIYO2_MAP_ALL ];
	n_bmp          bmp_old, bmp_new;

	n_posix_char *icon_name;
	int           icon_index;

	bool          init;
	u32           init_timer;
	bool          inputtable;

	s32           zoom;
	s32           unit;
	s32           map_sx, map_sy, map_all;
	s32           csx,csy;
	s32           info_sy, bar_sy, stripe;

	int           session_msec;
	int           combo_min;
	int           combo_msec;
	int           trans_msec;

	u32           color_none;
	u32           color_hover;
	u32           color_combo;
	u32           color_info;
	u32           color_bar;
	u32           color_shaft;
	u32           color_check_bg;
	u32           color_check_fg;

	bool          phase;
	bool          input;
	n_game_click  click;

	int           combo;
	int           countdown;
	int           score;

	n_bmp        *chara;

	UINT          timer_id_inactive;

} n_hunyapiyo2;

static n_hunyapiyo2 hunyapiyo2;




#include "./hunyapiyo2_subclass.c"




#define n_hunyapiyo2_is_inputtable( p, x,y ) ( ( ( x >= 0 )&&( x <     game.sx ) )&&( ( y >= 0 )&&( y <     game.sy ) ) )
#define n_hunyapiyo2_is_accessible( p, x,y ) ( ( ( x >= 0 )&&( x < (p)->map_sx ) )&&( ( y >= 0 )&&( y < (p)->map_sy ) ) )

inline n_game_chara*
n_hunyapiyo2_pos2chara( n_hunyapiyo2 *p, s32 x, s32 y )
{
	return &p->chr[ x + ( p->map_sx * y ) ];
}

void
n_hunyapiyo2_shuffle( n_hunyapiyo2 *p )
{

	int i = 0;
	while( 1 )
	{

		n_game_chara *f = &p->chr[ i ];

		f->chara = &p->bmp[ n_game_random( N_HUNYAPIYO2_BMP_ALL ) ];
		f->data  = N_HUNYAPIYO2_CLICKED;


		i++;
		if ( i >= p->map_all ) { break; }
	}


	return;
}

#define n_hunyapiyo2_zero( p ) n_memory_zero( p, sizeof( n_hunyapiyo2 ) )

void
n_hunyapiyo2_init( n_hunyapiyo2 *p )
{

	// Global

	n_bmp_safemode = false;
	n_game_progressbar_animation = N_GAME_PROGRESSBAR_ANIMATION_ON_DOWN;


	// Size

	s32 desktop_sx; n_win_desktop_size( &desktop_sx, NULL );
	p->zoom = n_posix_max_s32( 1, desktop_sx / 800 );

	p->unit    = 48 * p->zoom;
	p->map_sx  = N_HUNYAPIYO2_MAP_SX;
	p->map_sy  = N_HUNYAPIYO2_MAP_SY;
	p->map_all = N_HUNYAPIYO2_MAP_ALL;
	p->csx     = p->unit * p->map_sx;
	p->csy     = p->unit * p->map_sy;
	p->info_sy = p->unit / 2;
	p->bar_sy  = p->info_sy / 3;
	p->stripe  = p->unit / 8;


	// Color

	n_game_dwm_onoff();

	p->color_none     = n_bmp_rgb(   0,200,255 );
	p->color_hover    = n_bmp_rgb(   0,150,200 );
	p->color_combo    = n_bmp_rgb( 200,255,255 );
	p->color_info     = n_bmp_rgb(   1,  1,  1 );
	p->color_bar      = n_bmp_rgb(   0,200,255 );
	p->color_shaft    = n_bmp_rgb(   0,150,200 );
	p->color_check_bg = p->color_none;
	p->color_check_fg = p->color_combo;

	if ( game.dwm_onoff )
	{

		u32 fg = n_win_dwm_windowcolor();

		p->color_none     = n_bmp_black_invisible;
		p->color_hover    = n_bmp_blend_pixel( fg, n_bmp_black, 0.5 );
		p->color_combo    = n_bmp_blend_pixel( fg, n_bmp_white, 0.5 );
		p->color_info     = n_bmp_alpha_replace_pixel( p->color_info,  222 );
		p->color_bar      = n_bmp_alpha_replace_pixel( p->color_bar,   222 );
		p->color_shaft    = n_bmp_alpha_replace_pixel( p->color_shaft, 222 );
		p->color_check_bg = p->color_hover;
		p->color_check_fg = p->color_combo;

	}


	// System

	n_game_title_literal( "hunyapiyo2" );

	game.sx       = p->csx;
	game.sy       = p->csy + p->info_sy;
	game.fps      = 30;
	game.color    = p->color_none;
	game.on_close = n_hunyapiyo2_on_close;
	game.on_event = n_hunyapiyo2_on_event;

	if ( p->timer_id_inactive == 0 ) { p->timer_id_inactive = n_win_timer_id_get(); }
	n_win_timer_init( game.hwnd, p->timer_id_inactive, 33 );

	{
		s32 patch_sx = 9;
		s32 patch_sy = 9;

		int dpi = n_win_dpi( game.hwnd );

		if ( dpi >= 168 )
		{
			// [!] : 175% or more
			patch_sx += 7;
			patch_sy += 7;
		}

		n_win_set_patch( game.hwnd, &game.sx, &game.sy, patch_sx, patch_sy );
	}

	n_game_click_init( &p->click, VK_LBUTTON );

	p->phase        = N_HUNYAPIYO2_PHASE_FIRST;
	p->session_msec = 1000 * 30;
	p->combo_msec   = 1000 / 2;
	p->trans_msec   = 1000 / 2;
	p->combo_min    = p->map_sx;

	n_game_window_fixed();

	if ( IsZoomed( game.hwnd ) ) { ShowWindow( game.hwnd, SW_RESTORE ); }


	// Resources

#ifndef N_GAMECONSOLE
	p->icon_name  = n_posix_literal( "./hunyapiyo2.exe" );
#else // #ifndef N_GAMECONSOLE
	p->icon_name  = n_posix_literal( "./gameconsole.exe" );
#endif // #ifndef N_GAMECONSOLE

	p->icon_index = N_GAMECONSOLE_ICON_OFFSET_HUNYAPIYO2;

	n_game_rc_load_bmp_literal( &p->bmp[ 0 ], "HUNYAPIYO2_BMP_0" );
	n_game_rc_load_bmp_literal( &p->bmp[ 1 ], "HUNYAPIYO2_BMP_1" );
	n_game_rc_load_bmp_literal( &p->bmp[ 2 ], "HUNYAPIYO2_BMP_2" );
	n_game_rc_load_bmp_literal( &p->bmp[ 3 ], "HUNYAPIYO2_BMP_3" );
	n_game_rc_load_bmp_literal( &p->bmp[ 4 ], "HUNYAPIYO2_BMP_4" );

	n_bmp_scaler_big( &p->bmp[ 0 ], p->zoom );
	n_bmp_scaler_big( &p->bmp[ 1 ], p->zoom );
	n_bmp_scaler_big( &p->bmp[ 2 ], p->zoom );
	n_bmp_scaler_big( &p->bmp[ 3 ], p->zoom );
	n_bmp_scaler_big( &p->bmp[ 4 ], p->zoom );


	n_game_sound_bulk_zero( p->snd, N_HUNYAPIYO2_WAV_ALL );

	n_game_sound_init_literal( &p->snd[ 0 ], game.hwnd, "HUNYAPIYO2_WAV_0" );
	n_game_sound_init_literal( &p->snd[ 1 ], game.hwnd, "HUNYAPIYO2_WAV_1" );
	n_game_sound_init_literal( &p->snd[ 2 ], game.hwnd,  HUNYAPIYO2_WAV_2  );


	{ // n_hunyapiyo2_reset()


	// Blocks

	n_game_chara_bulk_zero( p->chr, p->map_all );


	int i = 0;
	int x = 0;
	int y = 0;
	while( 1 )
	{

		n_game_chara_bmp( &p->chr[ i ], &game.bmp, NULL, NULL, p->color_none );
		n_game_chara_pos( &p->chr[ i ], x,y );
		n_game_chara_prv( &p->chr[ i ] );
		n_game_chara_src( &p->chr[ i ], 0,0, p->unit, p->unit, 0,0 );


		i++;
		x += p->unit;
		if ( x >= p->csx )
		{

			x = 0;

			y += p->unit;
			if ( y >= p->csy ) { break; }
		}
	}


	n_hunyapiyo2_shuffle( p );


	} // n_hunyapiyo2_reset()



	return;
}

void
n_hunyapiyo2_exit( n_hunyapiyo2 *p )
{

	int i;


	i = 0;
	while( 1 )
	{

		n_bmp_free( &p->bmp[ i ] );

		i++;
		if ( i >= N_HUNYAPIYO2_BMP_ALL ) { break; }
	}

	n_bmp_free( &p->bmp_old );
	n_bmp_free( &p->bmp_new );


	i = 0;
	while( 1 )
	{

		n_game_sound_exit( &p->snd[ i ] );

		i++;
		if ( i >= N_HUNYAPIYO2_WAV_ALL ) { break; }
	}


	n_hunyapiyo2_zero( p );


	return;
}

void
n_hunyapiyo2_fall( n_hunyapiyo2 *p, s32 x, s32 y )
{

	n_game_chara *lower, *upper;


	while( 1 )
	{

		if ( n_hunyapiyo2_is_accessible( p, x, y - 0 ) )
		{

			lower  = n_hunyapiyo2_pos2chara( p, x, y - 0 );

		} else {

			break;

		}

		if ( n_hunyapiyo2_is_accessible( p, x, y - 1 ) )
		{

			upper = n_hunyapiyo2_pos2chara( p, x, y - 1 );

		} else {

			lower->chara = &p->bmp[ n_game_random( N_HUNYAPIYO2_BMP_ALL ) ];
			lower->data  = N_HUNYAPIYO2_CLICKED;

			break;

		}


		lower->chara = upper->chara;
		lower->data  = N_HUNYAPIYO2_CLICKED;


		y--;

	}


	return;
}

bool
n_hunyapiyo2_logic( n_hunyapiyo2 *p, s32 fx, s32 fy, s32 tx, s32 ty )
{

	if ( false == n_hunyapiyo2_is_accessible( p, fx,fy ) ) { return false; }
	if ( false == n_hunyapiyo2_is_accessible( p, tx,ty ) ) { return false; }


	n_game_chara *f = n_hunyapiyo2_pos2chara( p, fx,fy );
	n_game_chara *t = n_hunyapiyo2_pos2chara( p, tx,ty );


	if ( p->chara == f->chara ) { return false; }
	if ( f->chara != t->chara ) { return false; }


	p->combo++; 

	if ( p->input )
	{
		t->data = N_HUNYAPIYO2_CHAINED;
	} else {
		t->data = N_HUNYAPIYO2_HILIGHT;
	}


	return true;
}

void
n_hunyapiyo2_draw( n_hunyapiyo2 *p )
{

	int i = 0;
	while( 1 )
	{

		n_game_chara *f = &p->chr[ i ];


		int p_data = f->data;

		if ( f->data == N_HUNYAPIYO2_HILIGHT )
		{

			f->data = N_HUNYAPIYO2_CLICKED;

			if ( p->combo >= p->combo_min )
			{
				f->bgcolor = p->color_combo;
			} else {
				f->bgcolor = p->color_hover;
			}

		} else
		if ( f->data == N_HUNYAPIYO2_CLICKED )
		{

			f->data    = N_HUNYAPIYO2_NONE;
			f->bgcolor = p->color_none;

		} else
		if ( f->data == N_HUNYAPIYO2_NONE )
		{

			if ( p->chara == f->chara )
			{
				f->data = N_HUNYAPIYO2_LOCKED;
			}

		} else
		if ( f->data == N_HUNYAPIYO2_LOCKED )
		{

			if ( p->chara != f->chara )
			{
				f->data  = N_HUNYAPIYO2_CLICKED;
			}

		}// else


		if ( p_data != f->data )
		{

			n_game_refresh_on();


			n_game_chara_erase( f );

			if ( f->data != N_HUNYAPIYO2_LOCKED )
			{
				n_game_chara_draw( f );
			}

		}


		i++;
		if ( i >= p->map_all ) { break; }
	}


	// Timer bar

	{

		n_bmp_box( &game.bmp, 0,p->csy, p->csx,p->info_sy, p->color_info );


		s32 o  = p->stripe;
		s32 x  = 0 + o;
		s32 y  = p->csy + n_game_centering( p->info_sy, p->bar_sy );
		s32 sx = p->csx - ( o * 2 );
		s32 sy = p->bar_sy;

		double pc = (double) 100 * ( (double) p->countdown / p->session_msec );

		n_game_progressbar_horz( &game.bmp, x,y,sx,sy, p->color_bar, p->color_shaft, pc, p->stripe );


		n_game_refresh_on();

	}


	return;
}

// internal
void
n_hunyapiyo2_scorebitmap( n_hunyapiyo2 *p, n_bmp *b )
{

	n_posix_char str[ 100 ];
	n_posix_sprintf_literal( str, "%d", p->score );


	n_gdi gdi;
	n_gdi_zero( &gdi );


	gdi.sx                 = game.sx;
	gdi.sy                 = game.sy;
	gdi.style              = N_GDI_SMOOTH | N_GDI_CONTOUR;
	gdi.layout             = N_GDI_LAYOUT_VERTICAL;

	gdi.base_color_bg      = p->color_check_bg;
	gdi.base_color_fg      = p->color_check_fg;
	gdi.base_style         = N_GDI_BASE_GINGHAM;
	gdi.base_unit          = p->unit / 2;

	gdi.frame_style        = N_GDI_FRAME_NOFRAME;

	gdi.icon               = p->icon_name;
	gdi.icon_index         = p->icon_index;
	gdi.icon_color_contour = n_bmp_white;
	gdi.icon_style         = N_GDI_ICON_RESOURCE;
	gdi.icon_fxsize2       = 2;

	gdi.text               = str;
	gdi.text_font          = n_project_stdfont();
	gdi.text_size          = p->unit;
	gdi.text_color_main    = p->color_hover;
	gdi.text_color_contour = n_bmp_white;
	gdi.text_style         = 0;//N_GDI_TEXT_BOLD;
	gdi.text_fxsize2       = 2;


	n_gdi_bmp( &gdi, b );


	return;
}

void
n_hunyapiyo2_transition( n_hunyapiyo2 *p )
{

	const int type = N_GAME_TRANSITION_SCROLL_L;


	if ( p->phase == N_HUNYAPIYO2_PHASE_FIRST )
	{
		p->phase = N_HUNYAPIYO2_PHASE_RESET;
	}


	if ( p->phase == N_HUNYAPIYO2_PHASE_START )
	{

		p->phase = N_HUNYAPIYO2_PHASE_LOOP1;


		n_game_sound_loop( &p->snd[ 2 ] );


		n_bmp_carboncopy( &game.bmp, &p->bmp_old );

		n_bmp_zero( &p->bmp_new );
		n_hunyapiyo2_scorebitmap( p, &p->bmp_new );

//n_bmp_save_literal( &p->bmp_old, "old.bmp" );
//n_bmp_save_literal( &p->bmp_new, "new.bmp" );

	} else

	if ( p->phase == N_HUNYAPIYO2_PHASE_LOOP1 )
	{

		bool ret = n_game_transition( &game.bmp, &p->bmp_old, &p->bmp_new, p->trans_msec, type );
		if ( ret ) { p->phase = N_HUNYAPIYO2_PHASE_SCORE; }

	} else

	if ( p->phase == N_HUNYAPIYO2_PHASE_SCORE )
	{

		p->phase = N_HUNYAPIYO2_PHASE_SLEEP;


		n_bmp_flush_fastcopy( &game.bmp, &p->bmp_old );


		// [!] : set 100% for progressbar temporarily

		p->countdown = p->session_msec;


		// [!] : game.bmp will be overwritten by game/chara.c

		p->chara = NULL;
		n_hunyapiyo2_shuffle( p );
		n_hunyapiyo2_draw( p );

		n_bmp_flush_fastcopy( &game.bmp, &p->bmp_new );


		// [!] : write back

		n_bmp_flush_fastcopy( &p->bmp_old, &game.bmp );

//n_bmp_save_literal( &p->bmp_old, "old.bmp" );
//n_bmp_save_literal( &p->bmp_new, "new.bmp" );

	} else

	if ( p->phase == N_HUNYAPIYO2_PHASE_SLEEP )
	{

		p->phase = N_HUNYAPIYO2_PHASE_LOOP2;

		n_posix_sleep( p->trans_msec * 4 );

	} else

	if ( p->phase == N_HUNYAPIYO2_PHASE_LOOP2 )
	{

		bool ret = n_game_transition( &game.bmp, &p->bmp_old, &p->bmp_new, p->trans_msec, type );
		if ( ret )
		{

			p->phase = N_HUNYAPIYO2_PHASE_RESET;

			n_bmp_free( &p->bmp_old );
			n_bmp_free( &p->bmp_new );

		}

	} else

	if ( p->phase == N_HUNYAPIYO2_PHASE_RESET )
	{

		p->phase     = N_HUNYAPIYO2_PHASE_STOP;
		p->input     = false;
		p->chara     = NULL;
		p->score     = 0;
		p->countdown = p->session_msec;

	}// else


	n_game_refresh_on();
	return;
}

void
n_hunyapiyo2_loop( n_hunyapiyo2 *p )
{

	// [!] : grace period

	if ( p->init == false )
	{
		p->init       = true;
		p->init_timer = n_posix_tickcount();
	} else
	if ( n_game_timer( &p->init_timer, 100 ) )
	{
		p->inputtable = true;
	}



	if ( p->phase != N_HUNYAPIYO2_PHASE_STOP )
	{
		n_hunyapiyo2_transition( p );
		return;
	}


	// Timer bar : this position is important

	{

		static u32 prv = 0;
		if ( prv == 0 ) { prv = n_posix_tickcount(); }

		u32 cur = n_posix_tickcount();

		// [!] : resume timer : see subclass
		if ( game.is_active == false ) { prv = cur; return; }

		p->countdown -= cur - prv;
		if ( p->countdown < 0 ) { p->phase = prv = 0; } else { prv = cur; }

	}


	// Draw

	n_hunyapiyo2_draw( p );


	// Event : after drawn


	// [!] : single-fire only

	p->click.threshold.x = p->click.threshold.y = p->unit;

	if ( p->inputtable )
	{
		p->input = n_game_click_single( &p->click );
	}


	s32 cursor_x, cursor_y;
	n_win_cursor_position_relative( game.hwnd, &cursor_x, &cursor_y );


	// [!] : anti-fault : area check => division
	//
	//	if order is division => area check
	//	-10 will be 0 : inputtable when title bar is clicked

	s32 x,y, tx,ty;

	if ( n_hunyapiyo2_is_inputtable( p, cursor_x, cursor_y ) )
	{

		tx = x = cursor_x / p->unit;
		ty = y = cursor_y / p->unit;

	} else {

		return;

	}

//n_game_hwndprintf_literal( "%d %d : %d", x,y, n_hunyapiyo2_is_accessible( p, x,y ) ); return;


	int i = p->combo = 0;
	while( 1 )
	{//break;

		if ( i == 0 ) { tx--; ty--; } else
		if ( i == 1 ) {       ty--; } else
		if ( i == 2 ) { tx++; ty--; } else

		if ( i == 3 ) { tx--;       } else
		// center
		if ( i == 4 ) { tx++;       } else

		if ( i == 5 ) { tx--; ty++; } else
		if ( i == 6 ) {       ty++; } else
		if ( i == 7 ) { tx++; ty++; }



		if ( false == n_hunyapiyo2_logic( p, x,y, tx,ty ) )
		{

			// [!] : back to the center

			tx = x;
			ty = y;


			i++;
			if ( i >= 8 ) { break; }
		}

	}


	// Center : need to process at last

	bool ret = n_hunyapiyo2_logic( p, x,y, x,y );

	if ( ( ret )&&( p->input ) )
	{

		if ( p->combo >= p->combo_min )
		{

			int score_msec = p->combo * p->combo_msec;

			p->countdown += score_msec;
			p->score     += score_msec;

			n_game_sound_loop( &p->snd[ 1 ] );

		} else {

			n_game_sound_loop( &p->snd[ 0 ] );

		}


		p->chara = n_hunyapiyo2_pos2chara( p, x,y )->chara;

	}


	// Block Falling

	x = y = 0;
	while( 1 )
	{//break;

		if ( n_hunyapiyo2_pos2chara( p, x,y )->data == N_HUNYAPIYO2_CHAINED )
		{
			n_hunyapiyo2_fall( p, x,y );
		}


		x++;
		if ( x >= p->map_sx )
		{

			x = 0;

			y++;
			if ( y >= p->map_sy ) { break; }
		}
	}


	return;
}




#ifndef N_GAMECONSOLE

void
n_game_init( void )
{

	n_hunyapiyo2_zero( &hunyapiyo2 );
	n_hunyapiyo2_init( &hunyapiyo2 );


	return;
}

void
n_game_loop( void )
{

	if ( n_win_is_input( VK_F5 ) )
	{
		n_hunyapiyo2_exit( &hunyapiyo2 );
		n_hunyapiyo2_init( &hunyapiyo2 );
		n_game_reset();
	}

	n_hunyapiyo2_loop( &hunyapiyo2 );


	return;
}

void
n_game_exit( void )
{

	n_hunyapiyo2_exit( &hunyapiyo2 );


	return;
}

#endif // #ifndef N_GAMECONSOLE

