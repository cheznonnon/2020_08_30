// Nonnon Game Test
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




typedef struct {

	bool init;

	int  mode, type;
	u32  fg, bg;

} n_gametest_gradient;




void
n_gametest_gradient_init( n_gametest_gradient *g )
{

	g->init = true;
	g->fg   = n_bmp_black;
	g->bg   = n_bmp_white;


	n_bmp_flush( &game.bmp, game.color );


	return;
}

void
n_gametest_gradient_loop( n_gametest_gradient *g )
{

	const int mode_min = 0;
	const int mode_max = 1;

	const n_posix_char *mode_str[] = {

		n_posix_literal( "Rectangle" ),
		n_posix_literal( "Circle"    ),

	};

	const int mode_value[] = {

		N_BMP_GRADIENT_RECTANGLE,
		N_BMP_GRADIENT_CIRCLE,

	};

	const int type_min = 0;
	const int type_max = 2;

	const n_posix_char *type_str[] = {

		n_posix_literal( "Centering"  ),
		n_posix_literal( "Horizontal" ),
		n_posix_literal( "Vertical"   ),

	};

	const int type_value[] = {

		N_BMP_GRADIENT_CENTERING,
		N_BMP_GRADIENT_HORIZONTAL,
		N_BMP_GRADIENT_VERTICAL,

	};


	if ( n_win_is_input( VK_UP ) )
	{
		g->mode = n_posix_min( mode_max, g->mode + 1 );
	} else
	if ( n_win_is_input( VK_DOWN ) )
	{
		g->mode = n_posix_max( mode_min, g->mode - 1 );
	} else
	if ( n_win_is_input( VK_RIGHT ) )
	{
		g->type = n_posix_min( type_max, g->type + 1 );
	} else
	if ( n_win_is_input( VK_LEFT ) )
	{
		g->type = n_posix_max( type_min, g->type - 1 );
	} else
	if ( n_win_is_input( VK_SPACE ) )
	{
		g->fg = n_game_randomcolor();
		g->bg = n_game_randomcolor();
	} else
	if ( n_win_is_input( VK_CONTROL ) )
	{
		g->fg = n_bmp_rgb(   0,200,255 );
		g->bg = n_bmp_rgb( 222,222,222 );
	} else
	if ( n_game_refresh_is_resize() )
	{
		//
	} else
	if ( g->init == false )
	{
		return;
	}


	n_posix_sleep( 200 );

	g->init = false;


	s32  x = 10;
	s32  y = 10; 
	s32 sx = game.sx - 20;
	s32 sy = game.sy - 20;

	u32 tick = n_posix_tickcount();
	n_bmp_gradient( &game.bmp, x,y,sx,sy, g->fg,g->bg, mode_value[ g->mode ] | type_value[ g->type ] );

	n_game_hwndprintf_literal
	(
		"Mode %s"
		" : "
		"Type %s"
		" : "
		"Tick : %d",
		mode_str[ g->mode ],
		type_str[ g->type ],
		(int) n_posix_tickcount() - tick
	);


	n_game_refresh_on();

	return;
}

void
n_gametest_gradient_exit( n_gametest_gradient *g )
{
	return;
}

