



#include  "../../nonnon/win32/win.c"

#include  "../../nonnon/project/macro.c"




LRESULT CALLBACK
WndProc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	static char cmdline[ N_PATH_MAX ];


	static NOTIFYICONDATA nid;
	static HICON          icon;


	switch( msg ) {


	case WM_CREATE :


		// window

		n_win_init_literal( hwnd, "Nonnon", "", "" );

		n_win_style_new( hwnd, WS_OVERLAPPEDWINDOW );

		n_win_set( hwnd, NULL, 128,128, N_WIN_SET_CENTERING );


		// init

		n_win_commandline( cmdline );

		ExtractIconEx( cmdline, 0, NULL, &icon, 1 );

		nid.cbSize           = sizeof( NOTIFYICONDATA );
		nid.hWnd             = hwnd;
		nid.uID              = 0;
		nid.uFlags           = NIF_ICON;
		nid.uCallbackMessage = 0;
		nid.hIcon            = icon;

		Shell_NotifyIcon( NIM_ADD, &nid );


		ShowWindow( hwnd, SW_NORMAL );

	break;


	case WM_DROPFILES :

		n_win_dropfiles( hwnd, wparam, cmdline );


		n_win_icon_exit( icon );

		ExtractIconEx( cmdline, 0, NULL, &icon, 1 );

		nid.hIcon = icon;

		Shell_NotifyIcon( NIM_MODIFY, &nid );

	break;


	case WM_CLOSE :

		ShowWindow( hwnd, SW_HIDE );


		Shell_NotifyIcon( NIM_DELETE, &nid );

		n_win_icon_exit( icon );


		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		PostQuitMessage( 0 );

	break;


	} // switch


	return DefWindowProc( hwnd, msg, wparam, lparam );
}

int WINAPI
WinMain( HINSTANCE hinst, HINSTANCE prv_hinst, LPSTR cmd, int show )
{
	return n_win_main( NULL, WndProc );
}

