// Nonnon Game
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_WIN32_GAME_TRANSITION
#define _H_NONNON_WIN32_GAME_TRANSITION




#include "../neutral/bmp/all.c"
#include "../neutral/random.c"


#include "./helper.c"




#define N_GAME_TRANSITION_NOTHING   0
#define N_GAME_TRANSITION_WIPE_X    1
#define N_GAME_TRANSITION_WIPE_Y    2
#define N_GAME_TRANSITION_SHUTTER   3
#define N_GAME_TRANSITION_INFLATE   4
#define N_GAME_TRANSITION_CIRCLE    5
#define N_GAME_TRANSITION_FADE      6
#define N_GAME_TRANSITION_DIZZY     7
#define N_GAME_TRANSITION_MOSAIC    8
#define N_GAME_TRANSITION_WHIRL     9
#define N_GAME_TRANSITION_SCROLL_U 10
#define N_GAME_TRANSITION_SCROLL_D 11
#define N_GAME_TRANSITION_SCROLL_L 12
#define N_GAME_TRANSITION_SCROLL_R 13
#define N_GAME_TRANSITION_LAST     13

static s32 n_game_transition_circle_x = 0;
static s32 n_game_transition_circle_y = 0;

static s32 n_game_transition_offset_x = 0;
static s32 n_game_transition_offset_y = 0;

static double n_game_transition_percent = 0;

bool
n_game_transition( n_bmp *bmp, n_bmp *bmp_old, n_bmp *bmp_new, u32 msec, int type )
{

	// [Mechanism]
	//
	//	bmp     : canvas
	//	bmp_old : this will disappear
	//	bmp_new : this will appear

	// [!] : Return Value
	//
	//	false : running
	//	true  : stop or error


	if ( n_bmp_error( bmp     ) ) { return true; }
	if ( n_bmp_error( bmp_old ) ) { return true; }
	if ( n_bmp_error( bmp_new ) ) { return true; }

	if ( N_BMP_SX( bmp_old ) != N_BMP_SX( bmp_new ) ) { return true; }
	if ( N_BMP_SY( bmp_old ) != N_BMP_SY( bmp_new ) ) { return true; }


	// [!] : nothing to do

	if ( N_BMP_PTR( bmp_old ) == N_BMP_PTR( bmp_new ) ) { return true; }
	if ( N_BMP_PTR( bmp     ) == N_BMP_PTR( bmp_new ) ) { return true; }

	if ( msec == 0 ) { return true; }

	if ( ( type < 0 )||( type > N_GAME_TRANSITION_LAST ) ) { return true; }


	const s32 ox = n_game_transition_offset_x;
	const s32 oy = n_game_transition_offset_y;

	const s32 bmpsx = N_BMP_SX( bmp_new );
	const s32 bmpsy = N_BMP_SY( bmp_new );


	static double unit = 0;
	static double x,y,sx,sy;


	if ( type == N_GAME_TRANSITION_NOTHING )
	{

		// Performance : fastest

		if ( n_game_transition_percent == 0 )
		{
			n_bmp_fastcopy( bmp_old, bmp, 0,0,bmpsx,bmpsy, ox,oy );
		} else
		if ( n_game_transition_percent >= 100 )
		{
			n_bmp_fastcopy( bmp_new, bmp, 0,0,bmpsx,bmpsy, ox,oy );
		}

	} else

	if ( type == N_GAME_TRANSITION_WIPE_X )
	{

		// Performance : WIPE_X:WIPE_X = 1:1


		if ( n_game_transition_percent == 0 )
		{

			unit = ceil( (double) bmpsx * 0.01 );

			x  = ( bmpsx / 2 );
			y  =     0;
			sx =     0;
			sy = bmpsy;

			n_bmp_fastcopy( bmp_old, bmp, 0,0,bmpsx,bmpsy, ox,oy );

		}


		sx = n_posix_min_s32( bmpsx, unit * n_game_transition_percent );
		x  = ( bmpsx - sx ) / 2;

		n_bmp_fastcopy( bmp_new, bmp, x,y,sx,sy, ox + x,oy + y );

	} else

	if ( type == N_GAME_TRANSITION_WIPE_Y )
	{

		// Performance : WIPE_X:WIPE_Y = 1:1


		if ( n_game_transition_percent == 0 )
		{

			unit = ceil( (double) bmpsy * 0.01 );

			x  =     0;
			y  = ( bmpsy / 2 );
			sx = bmpsx;
			sy =     0;

			n_bmp_fastcopy( bmp_old, bmp, 0,0,bmpsx,bmpsy, ox,oy );

		}


		sy = n_posix_min_s32( bmpsy, unit * n_game_transition_percent );
		y  = ( bmpsy - sy ) / 2;

		n_bmp_fastcopy( bmp_new, bmp, x,y,sx,sy, ox + x,oy + y );

	} else

	if ( type == N_GAME_TRANSITION_SHUTTER )
	{

		// Performance : WIPE_X:SHUTTER = 1:1.5


		static s32 i, offset;


		if ( n_game_transition_percent == 0 )
		{

			unit = bmpsy;
			unit = ceil( (double) unit * 0.01 );

			x  =     0;
			y  =     0;
			sx = bmpsx;
			sy =     1;

			i = offset = 0;

			n_bmp_fastcopy( bmp_old, bmp, 0,0,bmpsx,bmpsy, ox,oy );

		}


		while( 1 )
		{//break;

			n_bmp_fastcopy( bmp_new, bmp, x,y, sx,sy, ox + x,ox + y );

			y += 10;
			if ( y >= bmpsy )
			{
				offset++;

				y = offset;
			}


			i++;
			if ( i >= ( unit * n_game_transition_percent ) ) { break; }
		}

	} else

	if ( type == N_GAME_TRANSITION_INFLATE )
	{

		// Performance : WIPE_X:INFLATE = 1:1.5


		if ( n_game_transition_percent == 0 )
		{

			unit = ceil( (double) n_posix_max_s32( bmpsx, bmpsy ) * 0.01 );

			x  = bmpsx / 2;
			y  = bmpsy / 2;
			sx = unit;
			sy = unit;

			n_bmp_fastcopy( bmp_old, bmp, 0,0,bmpsx,bmpsy, ox,oy );

		}


		s32 size = unit * n_game_transition_percent;


		x  = ( bmpsx - size ) / 2;
		y  = ( bmpsy - size ) / 2;
		sx = size;
		sy = size;

		n_bmp_fastcopy( bmp_new, bmp, x,y, sx,sy, ox + x,oy + y );

	} else

	if ( type == N_GAME_TRANSITION_CIRCLE )
	{

		// Performance : WIPE_X:CIRCLE = 1:3

		static int p_size = -1;

		if ( n_game_transition_percent == 0 )
		{

			s32 half_sx   = bmpsx / 2;
			s32 half_sy   = bmpsy / 2;
			s32 radius_sx = half_sx + abs( half_sx - n_game_transition_circle_x );
			s32 radius_sy = half_sy + abs( half_sy - n_game_transition_circle_y );
			s32 radius    = n_posix_max_s32( radius_sx, radius_sy );

			unit = ceil( (double) radius * sqrt( 2 ) );
			unit = ceil( (double) unit * 0.01 );

			n_bmp_fastcopy( bmp_old, bmp, 0,0,bmpsx,bmpsy, ox,oy );

			p_size = -1;

		}


		const s32 size = unit * n_game_transition_percent;

		x = y = 0;
		while( 1 )
		{

			s32 center_x = x - n_game_transition_circle_x;
			s32 center_y = y - n_game_transition_circle_y;

			bool outer = n_bmp_circle_detect( center_x,center_y,   size );
			bool inner = false;//n_bmp_circle_detect( center_x,center_y, p_size );

			while( outer )
			{//break;

				inner = n_bmp_circle_detect( center_x,center_y, p_size );
				if ( inner == false ) { break; }

				center_x++; x++;
				if ( x >= bmpsx ) { break; }
			}


			if ( ( inner == false )&&( outer ) )
			{

				u32 color;

				n_bmp_ptr_get_fast( bmp_new, x,y, &color );
/*
				if ( false == n_bmp_circle_detect( center_x,center_y, size - 2 ) )
				{
//color = 0x00ff0000;
					u32 c; n_bmp_ptr_get_fast( bmp, ox+x,oy+y, &c );
					color = n_bmp_blend_pixel( c, color, 0.5 );
				}
*/
				n_bmp_ptr_set_fast( bmp, ox+x,oy+y, color );

			} else
			if ( ( inner == false )&&( outer == false ) )
			{

				if ( center_x >= 0 ) { x = bmpsx; }

			}


			x++;
			if ( x >= bmpsx )
			{

				x = 0;

				y++;
				if ( y >= bmpsy ) { break; }
			}
		}

		p_size = size;

	} else

	if ( type == N_GAME_TRANSITION_FADE )
	{

		// WIPE_X:FADE = 1:12


		if ( n_game_transition_percent == 0 )
		{

			x  =     0;
			y  =     0;
			sx = bmpsx;
			sy = bmpsy;

			n_bmp_fastcopy( bmp_old, bmp, 0,0,bmpsx,bmpsy, ox,oy );

		}


		n_bmp_blendcopy_no_finalize( bmp_new, bmp, 0,0,bmpsx,bmpsy, ox,oy, (double) ( 100 - n_game_transition_percent ) * 0.01 );

	} else

	if ( type == N_GAME_TRANSITION_DIZZY )
	{

		// Performance : WIPE_X:DIZZY = 1:4


		if ( n_game_transition_percent == 0 )
		{

			const int boost = 2;


			unit = ceil( (double) ( bmpsx * bmpsy ) * 0.01 ) * boost;

			x  =     0;
			y  =     0;
			sx = bmpsx;
			sy = bmpsy;

			n_bmp_fastcopy( bmp_old, bmp, 0,0,bmpsx,bmpsy, ox,oy );

		}


		u32 color;

		s32 i = 0;
		while( 1 )
		{//break;

			x = n_random_range( bmpsx );
			y = n_random_range( bmpsy );


			n_bmp_ptr_get_fast( bmp_new, x,y, &color );
			n_bmp_ptr_set_fast( bmp, ox+x,oy+y, color );


			i++;
			if ( i >= unit ) { break; }
		}


		if ( n_game_transition_percent >= 70 )
		{
			n_bmp_blendcopy( bmp_new, bmp, 0,0,bmpsx,bmpsy, ox,oy, (double) ( 100 - n_game_transition_percent ) * 0.01 );
		}

	} else

	if ( type == N_GAME_TRANSITION_MOSAIC )
	{

		// Performance : WIPE_X:MOSAIC = 1:4


		if ( n_game_transition_percent == 0 )
		{

			n_bmp_fastcopy( bmp_old, bmp, 0,0,bmpsx,bmpsy, ox,oy );

		}


		n_bmp *bmp_sample;
		s32    half;

		if ( n_game_transition_percent <= 50 )
		{
			unit       = n_game_transition_percent;
			bmp_sample = bmp_old;
		} else {
			unit       = 100 - n_game_transition_percent;
			bmp_sample = bmp_new;
		}

		unit = n_posix_max_s32( 1, unit );
		half = unit / 2;


		s32 fx,fy, fsx,fsy, startx;
		u32 color;

		x = -( fmod( bmpsx, unit ) / 2 ); startx = x;
		y = -( fmod( bmpsy, unit ) / 2 );
		while( 1 )
		{

			fx = x + half;
			fy = y + half;

			n_bmp_error_clipping( bmp_sample,NULL, &fx,&fy,NULL,NULL, NULL,NULL );

			n_bmp_ptr_get( bmp_sample, fx,fy, &color );


			fx  = ox + x;
			fy  = oy + y;
			fsx = unit;
			fsy = unit;

			if ( fx < ox ) { fx = ox; }
			if ( fy < oy ) { fy = oy; }
			if ( ( fx + fsx ) >= ( ox + bmpsx ) ) { fsx = ( ox + bmpsx ) - fx; }
			if ( ( fy + fsy ) >= ( oy + bmpsy ) ) { fsy = ( oy + bmpsy ) - fy; }

			n_bmp_box( bmp, fx,fy,fsx,fsy, color );


			x += unit;
			if ( x >= bmpsx )
			{

				x = startx;

				y += unit;
				if ( y >= bmpsy ) { break; }
			}
		}


		if ( n_game_transition_percent >= 100 )
		{

			n_bmp_fastcopy( bmp_new, bmp, 0,0,bmpsx,bmpsy, ox,oy );

		}

	} else

	if ( type == N_GAME_TRANSITION_WHIRL )
	{

		// Performance : WIPE_X:WHIRL = 1:8


		static double degree, scale;


		if ( n_game_transition_percent == 0 )
		{

			degree = 45;
			scale  =  5;

		}


		n_bmp_fastcopy( bmp_new, bmp, 0,0,bmpsx,bmpsy, ox,oy );


		n_bmp b;

		n_bmp_carboncopy( bmp_old, &b );
		n_bmp_scaler_lil( &b, 2 + ( n_game_transition_percent / scale ) );
		n_bmp_matrix_rotate( &b, n_game_transition_percent * degree, n_bmp_white_invisible, true );
		n_bmp_resizer( &b, bmpsx,bmpsy, n_bmp_trans, N_BMP_RESIZER_CENTER );

		n_bmp_transcopy
		(
			&b, bmp,
			0,0,bmpsx,bmpsy,
			ox + n_game_centering( bmpsx, N_BMP_SX( &b ) ),
			oy + n_game_centering( bmpsy, N_BMP_SY( &b ) )
		);

		n_bmp_free( &b );


		if ( n_game_transition_percent >= 100 )
		{

			n_bmp_fastcopy( bmp_new, bmp, 0,0,bmpsx,bmpsy, ox,oy );

		}

	} else

	if ( ( type >= N_GAME_TRANSITION_SCROLL_U )&&( type <= N_GAME_TRANSITION_SCROLL_R ) )
	{

		// Performance : WIPE_X:SCROLL = 1:1


		if ( n_game_transition_percent == 0 )
		{
			sx = ceil( (double) bmpsx * 0.01 );
			sy = ceil( (double) bmpsy * 0.01 );
		}


		x = n_posix_min_s32( bmpsx, sx * n_game_transition_percent );
		y = n_posix_min_s32( bmpsy, sy * n_game_transition_percent );

//n_bmp_flush( bmp, 0 );

		if ( type == N_GAME_TRANSITION_SCROLL_U )
		{

			s32 fy  = y;
			s32 fsy = bmpsy - y;
			s32 ty  = 0;
			s32 tsy = y;

			n_bmp_fastcopy( bmp_old, bmp, 0,fy,bmpsx,fsy, ox,  0 + oy );
			n_bmp_fastcopy( bmp_new, bmp, 0,ty,bmpsx,tsy, ox,fsy + oy );

		} else
		if ( type == N_GAME_TRANSITION_SCROLL_D )
		{

			s32 fy  = 0;
			s32 fsy = bmpsy - y;
			s32 ty  = bmpsy - y;
			s32 tsy = y;

			n_bmp_fastcopy( bmp_old, bmp, 0,fy,bmpsx,fsy, ox,y + oy );
			n_bmp_fastcopy( bmp_new, bmp, 0,ty,bmpsx,tsy, ox,0 + oy );

		} else
		if ( type == N_GAME_TRANSITION_SCROLL_L )
		{

			s32 fx  = x;
			s32 fsx = bmpsx - x;
			s32 tx  = 0;
			s32 tsx = x;

			n_bmp_fastcopy( bmp_old, bmp, fx,0,fsx,bmpsy,   0 + ox,oy );
			n_bmp_fastcopy( bmp_new, bmp, tx,0,tsx,bmpsy, fsx + ox,oy );

		} else
		if ( type == N_GAME_TRANSITION_SCROLL_R )
		{

			s32 fx  = 0;
			s32 fsx = bmpsx - x;
			s32 tx  = bmpsx - x;
			s32 tsx = x;

			n_bmp_fastcopy( bmp_old, bmp, fx,0,fsx,bmpsy, x + ox,oy );
			n_bmp_fastcopy( bmp_new, bmp, tx,0,tsx,bmpsy, 0 + ox,oy );

		}

	}// else


	if ( n_game_transition_percent >= 100 )
	{

		n_game_transition_percent = 0;

		return true;

	} else {

		// Auto-adjuster

		static double frame_msec = 0;
		static double tick_count = 0;

		if ( n_game_transition_percent == 0 )
		{
			frame_msec = (double) msec / 100;
			tick_count = n_posix_tickcount();
		}

		double tick_count_cur   = n_posix_tickcount();
		double tick_count_delta = tick_count_cur - tick_count;

		if ( frame_msec < tick_count_delta )
		{

			n_game_transition_percent += ceil( tick_count_delta / frame_msec );

			n_posix_sleep( frame_msec - fmod( tick_count_delta, frame_msec ) );

		} else
		if ( frame_msec > tick_count_delta )
		{

			n_posix_sleep( frame_msec - tick_count_delta );

			n_game_transition_percent++;

		} else {

			n_game_transition_percent++;

		}

		tick_count = tick_count_cur;

		n_game_transition_percent = n_posix_minmax_double( 0, 100, n_game_transition_percent );

	}


	return false;
}


#endif // _H_NONNON_WIN32_GAME_TRANSITION

