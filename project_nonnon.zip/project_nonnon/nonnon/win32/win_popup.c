// Popup Window Helper Functions
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_WIN32_WIN_POPUP
#define _H_NONNON_WIN32_WIN_POPUP




#include "./sysinfo/version.c"

#include "./win.c"




void
n_win_popup_autostyle( HWND hwnd, s32 *csx, s32 *csy )
{

	n_win_style_dropshadow_onoff( hwnd, true );

	n_win_exstyle_new( hwnd, WS_EX_TOOLWINDOW );

	s32 border_sx, border_sy;

	if ( n_win_style_is_classic() )
	{

		n_win_style_new( hwnd, WS_POPUP | WS_DLGFRAME );

		border_sx = GetSystemMetrics( SM_CXFIXEDFRAME );
		border_sy = GetSystemMetrics( SM_CYFIXEDFRAME );

	} else {

		// [!] : Win10 : a temporary setting
		//
		//	build 10130 : still needed
		//	build 10162 : still needed
		//	build 10240 : still needed

		if ( n_sysinfo_version_10_or_later() )
		{

			n_win_style_new( hwnd, WS_POPUP | WS_BORDER );

			border_sx = GetSystemMetrics( SM_CXBORDER );
			border_sy = GetSystemMetrics( SM_CYBORDER );

		} else
		if ( n_win_dwm_is_on() )
		{

			n_win_style_new( hwnd, WS_POPUP | WS_SIZEBOX );

			border_sx = GetSystemMetrics( SM_CXSIZEFRAME );
			border_sy = GetSystemMetrics( SM_CYSIZEFRAME );

		} else {

			n_win_style_new( hwnd, WS_POPUP | WS_BORDER );

			border_sx = GetSystemMetrics( SM_CXBORDER );
			border_sy = GetSystemMetrics( SM_CYBORDER );

		}
	}

	if ( csx != NULL ) { (*csx) = border_sx; }
	if ( csy != NULL ) { (*csy) = border_sy; }


	return;
}

void
n_win_popup_automove( HWND hwnd, s32 csx, s32 csy )
{

	// Phase 1 : add frames

#ifdef _MSC_VER

	s32 border_sx,border_sy; n_win_popup_autostyle( hwnd, &border_sx, &border_sy );

	csx += border_sx;
	csy += border_sy;

	// [x] : reason is unknown

	if ( n_sysinfo_version_10_or_later() )
	{
		//
	} else {
		csx += 3;
		csy += 3;
	}

#endif // #ifdef _MSC_VER

	n_win w; n_win_set( hwnd, &w, csx,csy, N_WIN_SET_CALCONLY );


	// Phase 2 : get current cursor position

	{

		POINT cursor;
		GetCursorPos( &cursor );

		w.posx = cursor.x;
		w.posy = cursor.y;
	}


	// Phase 3 : centering

	int taskbar; n_win_taskbarpos( &taskbar, NULL );

//n_txt_debug_printf_literal( "%d", taskbar );


	if ( ( taskbar == ABE_TOP )||( taskbar == ABE_BOTTOM ) )
	{
		w.posx -= w.wsx / 2;
	} else
	if ( ( taskbar == ABE_LEFT )||( taskbar == ABE_RIGHT ) )
	{
		w.posy -= w.wsy / 2;
	}


	// Phase 4 : drawing

	n_win_set( hwnd, &w, w.csx,w.csy, N_WIN_SET_NEEDPOS | N_WIN_SET_INNERPOS );


	return;
}

void
n_win_popup_patch( HWND hwnd, UINT msg, WPARAM *wparam, LPARAM *lparam, HWND hpopup )
{

	// [!] : suppress gray-out when "hpopup" is active

	switch( msg ) {

	case WM_NCACTIVATE :

		if ( (*wparam) == false )
		{
			(*wparam) = IsWindow( hpopup );
		}

	break;

	} // switch


	// [!] : restoring is needed when "hpopup" is closed

	static bool onoff = false;

	if ( IsWindow( hpopup ) )
	{

		onoff = true;

	} else
	if ( onoff )
	{

		onoff = false;


		HWND  h       = n_win_cursor2hwnd();
		bool  restore = false;


		if (
			( hwnd == h )
			||
			( IsChild(   hwnd, h ) )
			||
			( IsChild( hpopup, h ) )
		)
		{
			restore = true;
		}


		n_win_message_send( hwnd, WM_NCACTIVATE, restore, 0 );


		// [!] : Win95 : hangup
		//
		//	don't use SetActiveWindow( hwnd );

		if ( restore ) { SetFocus( hwnd ); }

	}


	return;
}


#endif // _H_NONNON_WIN32_WIN_POPUP

