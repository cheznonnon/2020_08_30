// CatPad
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




void
n_win_txtbox_ime_watch_color( n_win_txtbox *p )
{

	if ( p->ime_onoff )
	{
		p->color_back_selected = p->color___ime_watcher;
	} else {
		p->color_back_selected = p->color_border__focus;
	}

	// [ Mechanism ]
	//
	//	.color_back_linenum1	background color
	//	.color_back_linenum2	selected color
	//	.color_back_linenum3	indicator color
	//
	//	.color_text_linenum2	selected text color

	double ratio; if ( n_win_darkmode_onoff ) { ratio = 0.25; } else { ratio = 0.10; }
	p->color_back_striping = n_win_color_blend( p->color_back_noselect, p->color_back_selected, ratio );
	p->color_back_linenum1 = p->color_back_striping;
	p->color_back_linenum2 = n_win_color_blend( p->color_back_linenum1, p->color_back_selected, 0.25  );
	p->color_back_linenum3 = p->color_back_selected;
	p->color_text_linenum2 = n_win_color_blend( p->color_text_noselect, p->color_back_linenum2, 0.50  );

	p->color_text_tab_mark = n_win_color_blend( p->color_back_noselect, p->color_back_selected, 0.50  );
	p->color_text_eol_mark = n_win_color_blend( p->color_back_noselect, p->color_back_selected, 0.50  );


	return;
}

void
n_win_txtbox_ime_watch( n_win_txtbox *p )
{

	if ( false == ( p->style & N_WIN_TXTBOX_STYLE_EDITBOX ) ) { return; }


	p->ime_onoff = n_win_ime_is_on( p->hwnd );

	n_win_txtbox_ime_watch_color( p );

	if ( p->hwnd == GetFocus() )
	{
		n_win_txtbox_fade_go( p, p->color_back_selected );
	}

	n_win_timer_init( p->hwnd, p->caret_timer, p->caret_msec );

	n_win_txtbox_refresh( p );

	n_win_txtbox_on_setcursor( p );


	return;
}


