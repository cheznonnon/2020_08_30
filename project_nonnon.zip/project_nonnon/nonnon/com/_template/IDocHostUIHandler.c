// Nonnon COM : IDocHostUIHandler
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Template File : copy and modify if needed


// [!] : CLSID_WebBrowser : HTMLDocument2 has ICustonDoc




#ifndef _H_NONNON_WIN32_COM_IDOCHOSTUIHANDLER
#define _H_NONNON_WIN32_COM_IDOCHOSTUIHANDLER




HRESULT __stdcall
n_IDocHostUIHandler_IUnknown_QueryInterface( void *_this, REFIID iid, void **ppvObject )
{
n_com_debug_IUnknown_QueryInterface( _this, iid, ppvObject );


	if ( ppvObject == NULL ) { return E_POINTER; } else { (*ppvObject) = NULL; }


	GUID u = n_com_guid( n_guid_IID_IUnknown );
	GUID d = n_com_guid( n_guid_IID_IDispatch );
	GUID o = n_com_guid( n_guid_IID_IDocHostUIHandler );


	if (
		( IsEqualGUID( iid, &u ) )
		||
		( IsEqualGUID( iid, &d ) )
		||
		( IsEqualGUID( iid, &o ) )
	)
	{

		if ( ppvObject != NULL ) {  (*ppvObject) = _this; }

		return S_OK;

	}


	return E_NOINTERFACE;
}




HRESULT __stdcall
n_IDocHostUIHandler_ShowContextMenu
(
	IDocHostUIHandler *_this,
	DWORD              dwID,
	POINT             *ppt,
	IUnknown          *pcmdtReserved,
	IDispatch         *pdispReserved
)
{
N_COM_DEBUG_LISTBOX_SET_A( "IDocHostUIHandler_ShowContextMenu" );


	// [MSDN] : S_OK : no context menu

	//return S_OK;


	return S_FALSE;
}

HRESULT __stdcall
n_IDocHostUIHandler_GetHostInfo( IDocHostUIHandler *_this, DOCHOSTUIINFO *pInfo )
{
N_COM_DEBUG_LISTBOX_SET_A( "IDocHostUIHandler_GetHostInfo" );

	pInfo->cbSize        = sizeof( DOCHOSTUIINFO );
	pInfo->dwFlags       = DOCHOSTUIFLAG_FLAT_SCROLLBAR | DOCHOSTUIFLAG_THEME | DOCHOSTUIFLAG_DPI_AWARE;
	//pInfo->dwDoubleClick = DOCHOSTUIDBLCLK_DEFAULT;
	pInfo->pchHostCss    = NULL;
	pInfo->pchHostNS     = NULL;


	return S_OK;
}

HRESULT __stdcall
n_IDocHostUIHandler_ShowUI
(
	IDocHostUIHandler       *_this,
	DWORD                    dwID,
	IOleInPlaceActiveObject *pActiveObject,
	IOleCommandTarget       *pCommandTarget,
	IOleInPlaceFrame        *pFrame,
	IOleInPlaceUIWindow     *pDoc
)
{
N_COM_DEBUG_LISTBOX_SET_A( "IDocHostUIHandler_ShowUI" );

	return E_NOTIMPL;
}

HRESULT __stdcall
n_IDocHostUIHandler_HideUI( IDocHostUIHandler *_this )
{
N_COM_DEBUG_LISTBOX_SET_A( "IDocHostUIHandler_HideUI" );

	return E_NOTIMPL;
}

HRESULT __stdcall
n_IDocHostUIHandler_UpdateUI( IDocHostUIHandler *_this )
{
N_COM_DEBUG_LISTBOX_SET_A( "IDocHostUIHandler_UpdateUI" );

	return E_NOTIMPL;
}

HRESULT __stdcall
n_IDocHostUIHandler_EnableModeless( IDocHostUIHandler *_this, BOOL fEnable )
{
N_COM_DEBUG_LISTBOX_SET_A( "IDocHostUIHandler_EnableModeless" );

	return E_NOTIMPL;
}

HRESULT __stdcall
n_IDocHostUIHandler_OnDocWindowActivate( IDocHostUIHandler *_this, BOOL fActivate )
{
N_COM_DEBUG_LISTBOX_SET_A( "IDocHostUIHandler_OnDocWindowActivate" );

	return E_NOTIMPL;
}

HRESULT __stdcall
n_IDocHostUIHandler_OnFrameWindowActivate( IDocHostUIHandler *_this, BOOL fActivate )
{
N_COM_DEBUG_LISTBOX_SET_A( "IDocHostUIHandler_OnFrameWindowActivate" );

	return E_NOTIMPL;
}

HRESULT __stdcall
n_IDocHostUIHandler_ResizeBorder( IDocHostUIHandler *_this, LPCRECT prcBorder, IOleInPlaceUIWindow *pUIWindow, BOOL fRameWindow )
{
N_COM_DEBUG_LISTBOX_SET_A( "IDocHostUIHandler_ResizeBorder" );

	return E_NOTIMPL;
}

HRESULT __stdcall
n_IDocHostUIHandler_TranslateAccelerator( IDocHostUIHandler *_this, LPMSG lpMsg, const GUID *pguidCmdGroup, DWORD nCmdID )
{
N_COM_DEBUG_LISTBOX_SET_A( "IDocHostUIHandler_TranslateAccelerator" );

	return E_NOTIMPL;
}

HRESULT __stdcall
n_IDocHostUIHandler_GetOptionKeyPath( IDocHostUIHandler *_this, LPOLESTR *pchKey, DWORD dw )
{
N_COM_DEBUG_LISTBOX_SET_A( "IDocHostUIHandler_GetOptionKeyPath" );

	return E_NOTIMPL;
}

HRESULT __stdcall
n_IDocHostUIHandler_GetDropTarget( IDocHostUIHandler *_this, IDropTarget *pDropTarget, IDropTarget **ppDropTarget )
{
N_COM_DEBUG_LISTBOX_SET_A( "IDocHostUIHandler_GetDropTarget" );

	return E_NOTIMPL;
}

HRESULT __stdcall
n_IDocHostUIHandler_GetExternal( IDocHostUIHandler *_this, IDispatch **ppDispatch )
{
N_COM_DEBUG_LISTBOX_SET_A( "IDocHostUIHandler_GetExternal" );

	(*ppDispatch) = NULL;

	return E_NOTIMPL;
}

HRESULT __stdcall
n_IDocHostUIHandler_TranslateUrl( IDocHostUIHandler *_this, DWORD dwTranslate, OLECHAR *pchURLIn, OLECHAR **ppchURLOut )
{
N_COM_DEBUG_LISTBOX_SET_A( "IDocHostUIHandler_TranslateUrl" );

	return E_NOTIMPL;
}

HRESULT __stdcall
n_IDocHostUIHandler_FilterDataObject( IDocHostUIHandler *_this, IDataObject *pDO, IDataObject **ppDORet )
{
N_COM_DEBUG_LISTBOX_SET_A( "IDocHostUIHandler_FilterDataObject" );

	return E_NOTIMPL;
}




const void *n_IDocHostUIHandler_Vtbl[] = {

	n_IDocHostUIHandler_IUnknown_QueryInterface,
	n_com_IUnknown_AddRef,
	n_com_IUnknown_Release,

	n_IDocHostUIHandler_ShowContextMenu,
	n_IDocHostUIHandler_GetHostInfo,
	n_IDocHostUIHandler_ShowUI,
	n_IDocHostUIHandler_HideUI,
	n_IDocHostUIHandler_UpdateUI,
	n_IDocHostUIHandler_EnableModeless,
	n_IDocHostUIHandler_OnDocWindowActivate,
	n_IDocHostUIHandler_OnFrameWindowActivate,
	n_IDocHostUIHandler_ResizeBorder,
	n_IDocHostUIHandler_TranslateAccelerator,
	n_IDocHostUIHandler_GetOptionKeyPath,
	n_IDocHostUIHandler_GetDropTarget,
	n_IDocHostUIHandler_GetExternal,
	n_IDocHostUIHandler_TranslateUrl,
	n_IDocHostUIHandler_FilterDataObject,

};


IDocHostUIHandler n_IDocHostUIHandler_instance = { (void*) n_IDocHostUIHandler_Vtbl };




#endif // _H_NONNON_WIN32_COM_IDOCHOSTUIHANDLER

