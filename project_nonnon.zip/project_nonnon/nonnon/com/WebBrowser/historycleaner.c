// Nonnon COM : History Cleaner
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




#ifndef _H_NONNON_WIN32_COM_WEBBROWSER_HISTORYCLEANER
#define _H_NONNON_WIN32_COM_WEBBROWSER_HISTORYCLEANER




#include <wininet.h>




void
n_WebBrowser_historycleaner_IE4( void )
{

	// [ Compatibility ]
	//
	//	header : wininet.h
	//	link   : -lwininet // link is not needed
	//
	//	not work under Win7+IE8


	HMODULE hmod = LoadLibrary( n_posix_literal( "wininet.dll" ) );
	if ( hmod == NULL ) { return; }

#ifdef UNICODE
	FARPROC n_FindFirstUrlCacheEntry = GetProcAddress( hmod, "FindFirstUrlCacheEntryW" );
	FARPROC n_FindNextUrlCacheEntry  = GetProcAddress( hmod, "FindNextUrlCacheEntryW"  );
	FARPROC n_DeleteUrlCacheEntry    = GetProcAddress( hmod, "DeleteUrlCacheEntryW"    );
	FARPROC n_FindCloseUrlCache      = GetProcAddress( hmod, "FindCloseUrlCache"       );
#else  // #ifdef UNICODE
	FARPROC n_FindFirstUrlCacheEntry = GetProcAddress( hmod, "FindFirstUrlCacheEntryA" );
	FARPROC n_FindNextUrlCacheEntry  = GetProcAddress( hmod, "FindNextUrlCacheEntryA"  );
	FARPROC n_DeleteUrlCacheEntry    = GetProcAddress( hmod, "DeleteUrlCacheEntryA"    );
	FARPROC n_FindCloseUrlCache      = GetProcAddress( hmod, "FindCloseUrlCache"       );
#endif // #ifdef UNICODE

	if (
		( n_FindFirstUrlCacheEntry == NULL )
		||
		( n_FindNextUrlCacheEntry  == NULL )
		||
		( n_DeleteUrlCacheEntry    == NULL )
		||
		( n_FindCloseUrlCache      == NULL )
	)
	{
		FreeLibrary( hmod );
		return;
	}


	// [x] : CLSID_InternetExplorer
	//
	//	IE locks cache files when running

	// [!] : FindFirstUrlCacheEntry()
	//
	//	NULL means "all entry"
	//
	//	IE6 : "cookie:" doesn't function
	//	FindFirstUrlCacheEntryEx() behaves the same
	//
	//	sizeof( INTERNET_CACHE_ENTRY_INFO ) == 80byte
	//
	//	the first call will be ERROR_INSUFFICIENT_BUFFER (122)
	//	the last  call will be ERROR_NO_MORE_ITEMS       (259)
	//
	//	[Buggy] : FindNextUrlCacheEntry() will always increments to the next entry

//n_posix_debug_literal( " %d ", sizeof( INTERNET_CACHE_ENTRY_INFO ) );


	DWORD                      buffer = 1024 * 1024;
	INTERNET_CACHE_ENTRY_INFO *cache  = malloc( buffer );
	HANDLE                     handle = NULL;
	DWORD                      byte   = 0;
	DWORD                      error  = 0;


	while( 1 )
	{

		byte   = buffer;
		handle = (HANDLE) n_FindFirstUrlCacheEntry( NULL, cache, &byte );
		error  = GetLastError();
//n_posix_debug_literal( " %d : %d : %d ", ( handle == NULL ), (int) byte, (int) error );

		if ( error == 0 )
		{
			n_DeleteUrlCacheEntry( cache->lpszSourceUrlName );
			break;
		} else
		if ( error == ERROR_INSUFFICIENT_BUFFER )
		{
			buffer *= 2;
			cache = realloc( cache, buffer );
		} else {
			break;
		}

	}

	while( handle != NULL )
	{

		byte   = buffer;
		         n_FindNextUrlCacheEntry( handle, cache, &byte );
		error  = GetLastError();
//n_posix_debug_literal( " %d : %d : %d ", ( handle == NULL ), (int) byte, (int) error );

		if ( error == 0 )
		{
			n_DeleteUrlCacheEntry( cache->lpszSourceUrlName );
		} else
		if ( error == ERROR_INSUFFICIENT_BUFFER )
		{
			buffer *= 2;
			cache = realloc( cache, buffer );
		} else {
			break;
		}

	}

	free( cache );


	n_FindCloseUrlCache( handle );


	FreeLibrary( hmod );


	return;
}

void
n_WebBrowser_historycleaner_IE7( void )
{

	n_posix_char *exe = n_posix_literal( "RunDll32.exe InetCpl.cpl,ClearMyTracksByProcess 4351" );


	// [!] : SW_HIDE will be ignored

	n_win_execute( exe, SW_NORMAL, true );


	return;
}

void
n_WebBrowser_historycleaner( void )
{

	int v = n_IWebBrowser2_version();
//n_posix_debug_literal( " %d ", v );

	if ( v >= 7 )
	{
		n_WebBrowser_historycleaner_IE7();
	} else
	if ( v >= 4 )
	{
		n_WebBrowser_historycleaner_IE4();
	}


	return;
}




#endif // _H_NONNON_WIN32_COM_WEBBROWSER_HISTORYCLEANER

